# Detaillierte Installationsanleitung

## Schritt-für-Schritt Installation

### Vorbereitung

#### 1. System vorbereiten

```bash
# System aktualisieren
sudo pacman -Syu

# Ansible installieren
sudo pacman -S ansible python-pip git

# Zusätzliche Python-Pakete
pip3 install jinja2 pyyaml
```

#### 2. Benutzer konfigurieren

```bash
# Ansible-Benutzer zu sudoers hinzufügen
echo "ihr_benutzername ALL=(ALL) NOPASSWD:ALL" | sudo tee /etc/sudoers.d/ansible-user

# SSH-Schlüssel generieren
ssh-keygen -t ed25519 -C "ansible@$(hostname)"
```

### Installation ausführen

#### 1. Dateien vorbereiten

```bash
# Arbeitsverzeichnis erstellen
mkdir ~/manjaro-mitm-protection
cd ~/manjaro-mitm-protection

# Alle Playbook-Dateien hierher kopieren
```

#### 2. Inventory anpassen

```bash
# inventory.ini bearbeiten
nano inventory.ini
```

Beispiel-Konfiguration:
```ini
[manjaro_hosts]
localhost ansible_connection=local

[manjaro_hosts:vars]
admin_email=ihre_email@example.com
primary_interface=enp0s3  # Ihre Netzwerkschnittstelle ermitteln mit: ip route | grep default
ssh_port=2222
```

#### 3. Netzwerkschnittstelle ermitteln

```bash
# Aktive Netzwerkschnittstellen anzeigen
ip route | grep default
ip addr show

# Hauptschnittstelle in inventory.ini eintragen
```

#### 4. Playbook testen

```bash
# Syntax-Check
ansible-playbook --syntax-check -i inventory.ini manjaro_mitm_protection.yml

# Trockenlauf
ansible-playbook --check -i inventory.ini manjaro_mitm_protection.yml
```

#### 5. Installation durchführen

```bash
# Vollständige Installation
ansible-playbook -i inventory.ini manjaro_mitm_protection.yml

# Bei Problemen mit detaillierter Ausgabe
ansible-playbook -vvv -i inventory.ini manjaro_mitm_protection.yml
```

### Nach der Installation

#### 1. Services überprüfen

```bash
# Status aller Services
sudo systemctl status arpwatch suricata fail2ban unbound sshd ufw

# Logs überprüfen
sudo journalctl -u arpwatch --since "5 minutes ago"
sudo journalctl -u suricata --since "5 minutes ago"
```

#### 2. Funktionalität testen

```bash
# MITM-Status überprüfen
sudo /usr/local/bin/mitm-status

# DNS-Funktionalität testen
dig @127.0.0.1 google.com +dnssec

# Firewall-Status
sudo ufw status verbose
```

#### 3. SSH-Verbindung testen

```bash
# Neue SSH-Verbindung auf Port 2222 testen
ssh -p 2222 ihr_benutzername@localhost
```

**WICHTIG**: Testen Sie die SSH-Verbindung, bevor Sie die aktuelle Sitzung beenden!

## Erweiterte Konfiguration

### E-Mail-Benachrichtigungen einrichten

#### 1. Postfix installieren

```bash
sudo pacman -S postfix

# Postfix konfigurieren
sudo nano /etc/postfix/main.cf
```

#### 2. SMTP-Relay konfigurieren (optional)

```bash
# Für Gmail oder andere SMTP-Provider
sudo nano /etc/postfix/sasl_passwd
```

### Monitoring-Dashboard (optional)

#### 1. Grafana installieren

```bash
# AUR-Helper (yay) installieren falls nicht vorhanden
sudo pacman -S --needed git base-devel
git clone https://aur.archlinux.org/yay.git
cd yay && makepkg -si

# Grafana installieren
yay -S grafana

# Grafana starten
sudo systemctl enable --now grafana-server
```

#### 2. Prometheus für Metriken

```bash
yay -S prometheus

# Prometheus konfigurieren
sudo nano /etc/prometheus/prometheus.yml
```

### Erweiterte Suricata-Regeln

#### 1. Emerging Threats Pro (kostenpflichtig)

```bash
# Registrierung bei Proofpoint ET Pro
# API-Key in Suricata-Update konfigurieren
sudo suricata-update add-source et/pro <your-api-key>
```

#### 2. Benutzerdefinierte Regeln

```bash
# Eigene Regeln hinzufügen
sudo nano /etc/suricata/rules/local.rules
```

## Fehlerbehebung

### Häufige Installationsfehler

#### 1. Ansible-Verbindungsfehler

```bash
# SSH-Agent starten
eval $(ssh-agent)
ssh-add ~/.ssh/id_ed25519

# Verbindung testen
ansible -i inventory.ini manjaro_hosts -m ping
```

#### 2. Berechtigungsfehler

```bash
# Sudo-Konfiguration überprüfen
sudo visudo

# Ansible-Benutzer in sudoers-Datei
echo "$(whoami) ALL=(ALL) NOPASSWD:ALL" | sudo tee /etc/sudoers.d/$(whoami)
```

#### 3. Paket-Installation fehlgeschlagen

```bash
# Pacman-Datenbank aktualisieren
sudo pacman -Sy

# Keyring-Probleme beheben
sudo pacman -S archlinux-keyring manjaro-keyring
sudo pacman-key --populate archlinux manjaro
```

#### 4. Service-Start-Fehler

```bash
# Systemd-Daemon neu laden
sudo systemctl daemon-reload

# Service-Status detailliert anzeigen
sudo systemctl status arpwatch.service -l
```

### Performance-Optimierung

#### 1. Suricata-Performance

```bash
# CPU-Kerne für Suricata
sudo nano /etc/suricata/suricata.yaml

# Threading-Konfiguration anpassen
threading:
  set-cpu-affinity: yes
  cpu-affinity:
    - management-cpu-set:
        cpu: [ 0 ]
    - receive-cpu-set:
        cpu: [ 1 ]
    - worker-cpu-set:
        cpu: [ 2, 3 ]
```

#### 2. Speicher-Optimierung

```bash
# Suricata-Speicherverbrauch begrenzen
# In suricata.yaml:
flow:
  memcap: 64mb
stream:
  memcap: 32mb
```

### Backup und Wiederherstellung

#### 1. Konfiguration sichern

```bash
# Backup-Skript erstellen
#!/bin/bash
BACKUP_DIR="/backup/mitm-protection-$(date +%Y%m%d)"
mkdir -p $BACKUP_DIR

cp -r /etc/suricata $BACKUP_DIR/
cp -r /etc/fail2ban $BACKUP_DIR/
cp /etc/ssh/sshd_config $BACKUP_DIR/
cp /etc/unbound/unbound.conf $BACKUP_DIR/
```

#### 2. Wiederherstellung

```bash
# Services stoppen
sudo systemctl stop arpwatch suricata fail2ban unbound

# Konfigurationen wiederherstellen
sudo cp -r /backup/mitm-protection-20250720/* /etc/

# Services neu starten
sudo systemctl start arpwatch suricata fail2ban unbound
```

## Automatisierung

### Cron-Jobs für Wartung

```bash
# Crontab bearbeiten
sudo crontab -e

# Tägliche Regel-Updates
0 2 * * * /usr/bin/suricata-update && /usr/bin/systemctl reload suricata

# Wöchentliche Berichte
0 6 * * 1 /usr/local/bin/mitm-status --report | mail -s "Weekly MITM Report" admin@example.com
```

### Ansible-Cron für regelmäßige Ausführung

```bash
# Playbook wöchentlich ausführen
0 3 * * 0 cd /home/ansible/manjaro-mitm-protection && ansible-playbook -i inventory.ini manjaro_mitm_protection.yml
```

## Integration mit anderen Tools

### SIEM-Integration

#### 1. ELK Stack

```bash
# Elasticsearch, Logstash, Kibana installieren
yay -S elasticsearch logstash kibana

# Suricata-Logs an Logstash weiterleiten
sudo nano /etc/logstash/conf.d/suricata.conf
```

#### 2. Splunk Universal Forwarder

```bash
# Splunk UF herunterladen und installieren
# Suricata EVE JSON-Logs konfigurieren
```

### Cloud-Integration

#### 1. AWS CloudWatch

```bash
# AWS CLI installieren
sudo pacman -S aws-cli

# CloudWatch-Agent konfigurieren
```

#### 2. Azure Monitor

```bash
# Azure CLI installieren
yay -S azure-cli

# Log Analytics-Agent installieren
```

## Compliance und Dokumentation

### Audit-Logs

```bash
# Auditd installieren und konfigurieren
sudo pacman -S audit

# Audit-Regeln für MITM-Schutz
sudo nano /etc/audit/rules.d/mitm-protection.rules
```

### Dokumentation generieren

```bash
# Automatische Dokumentation der aktuellen Konfiguration
sudo /usr/local/bin/mitm-status --json > system-config-$(date +%Y%m%d).json
```

Diese Installationsanleitung führt Sie durch alle notwendigen Schritte für eine erfolgreiche Implementierung des MITM-Schutzes auf Manjaro Linux.

