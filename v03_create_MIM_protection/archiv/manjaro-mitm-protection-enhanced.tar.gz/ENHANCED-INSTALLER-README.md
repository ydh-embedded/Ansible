# Enhanced MITM Protection Installer

## Übersicht

Das erweiterte Installationsskript `install-MITM-protection-enhanced.sh` bietet flexible Installationsoptionen für den MITM-Schutz auf Manjaro Linux-Systemen.

## Neue Features

### 🎯 Installationstypen

**1. Lokale Installation**
- Installation auf dem aktuellen System
- Direkte Paket-Installation
- Lokale Konfiguration

**2. Entfernte Installation**
- Installation auf einem anderen Manjaro-System
- SSH-basierte Verbindung
- Ansible-gesteuerte Bereitstellung

**3. Multi-Host Installation**
- Gleichzeitige Installation auf mehreren Systemen
- Zentrale Verwaltung über Ansible
- Skalierbare Bereitstellung

### 🔐 SSH-Management

**Automatische SSH-Konfiguration:**
- SSH-Schlüssel-Generierung
- Automatische Schlüssel-Verteilung
- Verbindungstests vor Installation

**Unterstützte Authentifizierung:**
- SSH-Schlüssel (empfohlen)
- Passwort-basierte Authentifizierung
- Verschiedene SSH-Ports

### 🌐 Netzwerk-Flexibilität

**Ziel-Host-Konfiguration:**
- IP-Adressen
- Hostnamen/FQDN
- Mehrere Hosts gleichzeitig
- Automatische Kompatibilitätsprüfung

## Verwendung

### Schnellstart

```bash
# Skript ausführbar machen
chmod +x install-MITM-protection-enhanced.sh

# Installation starten
./install-MITM-protection-enhanced.sh
```

### Interaktive Auswahl

Das Skript führt Sie durch folgende Schritte:

#### 1. Installationstyp wählen
```
Wählen Sie den Installationstyp:
1) Lokale Installation (auf diesem System)
2) Entfernte Installation (auf anderen Manjaro-Systemen)  
3) Multi-Host Installation (mehrere Systeme gleichzeitig)
```

#### 2. SSH-Konfiguration (für entfernte Installation)
- SSH-Benutzername eingeben
- SSH-Schlüssel-Pfad angeben
- Optional: Neuen SSH-Schlüssel generieren

#### 3. Ziel-Hosts konfigurieren
- **Einzelner Host**: IP-Adresse oder Hostname
- **Mehrere Hosts**: Komma-getrennte Liste
- Automatische Verbindungstests

#### 4. System-Konfiguration
- E-Mail für Benachrichtigungen
- SSH-Port (Standard: 2222)
- Netzwerkschnittstelle (automatisch erkannt)

### Beispiel-Szenarien

#### Lokale Installation
```bash
./install-MITM-protection-enhanced.sh
# Wählen Sie Option 1
# Folgen Sie den Anweisungen
```

#### Entfernte Installation auf einem Server
```bash
./install-MITM-protection-enhanced.sh
# Wählen Sie Option 2
# SSH-User: admin
# Ziel-Host: 192.168.1.100
```

#### Multi-Host Installation
```bash
./install-MITM-protection-enhanced.sh
# Wählen Sie Option 3
# Hosts: 192.168.1.100,192.168.1.101,server.example.com
```

## Technische Details

### Systemanforderungen

**Control Node (lokales System):**
- Ansible installiert (wird automatisch installiert)
- SSH-Client
- Internetverbindung
- 2GB freier Speicherplatz

**Ziel-Hosts:**
- Manjaro Linux oder Arch Linux
- SSH-Server aktiviert
- Sudo-Berechtigung für den SSH-Benutzer
- Internetverbindung
- 5GB freier Speicherplatz

### SSH-Konfiguration

**Automatische SSH-Schlüssel-Generierung:**
```bash
# Das Skript kann automatisch einen ED25519-Schlüssel erstellen
ssh-keygen -t ed25519 -C "benutzer@hostname" -f ~/.ssh/id_ed25519
```

**SSH-Schlüssel-Verteilung:**
```bash
# Automatische Verteilung auf Ziel-Hosts
ssh-copy-id -i ~/.ssh/id_ed25519.pub benutzer@ziel-host
```

### Ansible-Integration

**Automatische Inventory-Erstellung:**
```ini
[manjaro_hosts]
server1 ansible_host=192.168.1.100 ansible_user=admin
server2 ansible_host=192.168.1.101 ansible_user=admin

[manjaro_hosts:vars]
ansible_ssh_private_key_file=/home/user/.ssh/id_ed25519
admin_email=admin@example.com
ssh_port=2222
```

**Playbook-Ausführung:**
```bash
# Automatische Ausführung auf allen Hosts
ansible-playbook -i inventory.ini manjaro_mitm_protection.yml
```

## Erweiterte Funktionen

### Backup und Rollback

**Automatisches Backup:**
- SSH-Konfigurationen aller Hosts
- Firewall-Regeln
- Service-Konfigurationen
- Systemd-Service-Status

**Rollback bei Fehlern:**
- Automatische Wiederherstellung bei Fehlern
- SSH-Konfiguration zurücksetzen
- Services stoppen
- Ursprüngliche Einstellungen wiederherstellen

### Validierung und Tests

**Pre-Installation Checks:**
- Manjaro/Arch Linux Erkennung
- SSH-Verbindungstests
- Sudo-Berechtigung prüfen
- Systemressourcen validieren

**Post-Installation Verification:**
- Service-Status auf allen Hosts
- Ansible-Konnektivität testen
- MITM-Status-Checks ausführen

### Monitoring und Wartung

**Zentrale Verwaltung:**
```bash
# Status aller Hosts prüfen
ansible manjaro_hosts -m shell -a "/usr/local/bin/mitm-status" --become

# Services auf allen Hosts neu starten
ansible manjaro_hosts -m systemd -a "name=suricata state=restarted" --become

# Logs von allen Hosts sammeln
ansible manjaro_hosts -m shell -a "journalctl -u suricata --since '1 hour ago'" --become
```

## Fehlerbehebung

### Häufige Probleme

#### SSH-Verbindung fehlgeschlagen
```bash
# SSH-Konfiguration prüfen
ssh -v benutzer@ziel-host

# SSH-Agent starten
eval $(ssh-agent -s)
ssh-add ~/.ssh/id_ed25519
```

#### Ansible-Verbindung fehlgeschlagen
```bash
# Ansible-Konnektivität testen
ansible manjaro_hosts -m ping

# Inventory-Datei prüfen
cat ~/mitm-protection/inventory.ini
```

#### Sudo-Berechtigung fehlt
```bash
# Auf Ziel-Host: Benutzer zu sudoers hinzufügen
echo "benutzername ALL=(ALL) NOPASSWD:ALL" | sudo tee /etc/sudoers.d/benutzername
```

### Debug-Modus

```bash
# Detaillierte Ausgabe
bash -x ./install-MITM-protection-enhanced.sh

# Ansible-Debug
ansible-playbook -vvv manjaro_mitm_protection.yml
```

## Sicherheitshinweise

### SSH-Sicherheit
- Verwenden Sie SSH-Schlüssel statt Passwörter
- Deaktivieren Sie Root-Login
- Verwenden Sie nicht-Standard SSH-Ports
- Implementieren Sie Fail2ban für SSH

### Netzwerk-Sicherheit
- Konfigurieren Sie Firewalls auf allen Hosts
- Verwenden Sie VPN für entfernte Verwaltung
- Überwachen Sie Netzwerk-Traffic
- Implementieren Sie Network Segmentation

### Zugriffskontrolle
- Beschränken Sie SSH-Zugang auf notwendige IPs
- Verwenden Sie starke Passwörter/Schlüssel
- Implementieren Sie Multi-Faktor-Authentifizierung
- Regelmäßige Zugangsüberprüfung

## Wartung und Updates

### Regelmäßige Updates
```bash
# Alle Hosts aktualisieren
ansible manjaro_hosts -m pacman -a "update_cache=yes upgrade=yes" --become

# MITM-Schutz-Komponenten aktualisieren
ansible-playbook manjaro_mitm_protection.yml --tags "update"
```

### Monitoring
```bash
# Tägliche Status-Checks
ansible manjaro_hosts -m shell -a "/usr/local/bin/mitm-status --json" --become > daily-status.json

# Log-Analyse
ansible manjaro_hosts -m shell -a "grep 'MITM' /var/log/suricata/eve.json | tail -10" --become
```

Das erweiterte Installationsskript bietet maximale Flexibilität für verschiedene Deployment-Szenarien und vereinfacht die Verwaltung von MITM-Schutz in komplexen Umgebungen.

