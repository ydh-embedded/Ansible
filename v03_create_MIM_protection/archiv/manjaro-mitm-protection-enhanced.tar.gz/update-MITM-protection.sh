#!/bin/bash

# =============================================================================
# MANJARO LINUX MITM PROTECTION UPDATER
# =============================================================================
# Update-Skript für MITM-Schutz-Komponenten
# Autor: Manus AI
# Version: 1.0
# =============================================================================

set -euo pipefail

# Farben
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

LOG_FILE="/tmp/mitm-protection-update.log"
INSTALL_DIR="$HOME/mitm-protection"

# Logging-Funktion
log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" | tee -a "$LOG_FILE"
}

print_header() {
    echo -e "\n${BLUE}==============================================================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}==============================================================================${NC}\n"
}

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
    log "INFO" "$1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
    log "SUCCESS" "$1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
    log "WARNING" "$1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
    log "ERROR" "$1"
}

# System-Updates
update_system_packages() {
    print_header "SYSTEM-PAKETE AKTUALISIEREN"
    
    print_info "Aktualisiere Paketdatenbank..."
    sudo pacman -Sy
    
    print_info "Aktualisiere Sicherheitspakete..."
    local security_packages=(
        "arpwatch"
        "suricata"
        "fail2ban"
        "ufw"
        "unbound"
        "openssl"
    )
    
    for package in "${security_packages[@]}"; do
        if pacman -Qi "$package" &>/dev/null; then
            print_info "Aktualisiere $package..."
            sudo pacman -S --noconfirm "$package" || {
                print_warning "Konnte $package nicht aktualisieren"
            }
        fi
    done
    
    print_success "System-Pakete aktualisiert"
}

# Suricata-Regeln aktualisieren
update_suricata_rules() {
    print_header "SURICATA-REGELN AKTUALISIEREN"
    
    if command -v suricata-update &> /dev/null; then
        print_info "Aktualisiere Suricata-Regeln mit suricata-update..."
        sudo suricata-update || {
            print_warning "suricata-update fehlgeschlagen, verwende manuelle Methode"
            update_suricata_rules_manual
        }
    else
        print_info "suricata-update nicht verfügbar, verwende manuelle Methode..."
        update_suricata_rules_manual
    fi
    
    # Suricata-Konfiguration testen
    print_info "Teste Suricata-Konfiguration..."
    if sudo suricata -T -c /etc/suricata/suricata.yaml; then
        print_success "Suricata-Konfiguration ist gültig"
        
        # Suricata neu laden
        if systemctl is-active --quiet suricata; then
            print_info "Lade Suricata-Regeln neu..."
            sudo systemctl reload suricata
            print_success "Suricata-Regeln neu geladen"
        fi
    else
        print_error "Suricata-Konfiguration ist ungültig"
        return 1
    fi
}

# Manuelle Suricata-Regel-Aktualisierung
update_suricata_rules_manual() {
    print_info "Lade Emerging Threats Regeln herunter..."
    
    local temp_dir=$(mktemp -d)
    cd "$temp_dir"
    
    # Emerging Threats Rules herunterladen
    if wget -q "https://rules.emergingthreats.net/open/suricata/emerging.rules.tar.gz"; then
        print_info "Extrahiere neue Regeln..."
        tar -xzf emerging.rules.tar.gz
        
        # Alte Regeln sichern
        if [[ -d /etc/suricata/rules ]]; then
            sudo cp -r /etc/suricata/rules /etc/suricata/rules.backup.$(date +%Y%m%d)
        fi
        
        # Neue Regeln installieren
        sudo mkdir -p /etc/suricata/rules
        sudo cp -r rules/* /etc/suricata/rules/
        
        print_success "Suricata-Regeln manuell aktualisiert"
    else
        print_error "Konnte Emerging Threats Regeln nicht herunterladen"
        return 1
    fi
    
    # Aufräumen
    cd /
    rm -rf "$temp_dir"
}

# Fail2ban-Konfiguration aktualisieren
update_fail2ban_config() {
    print_header "FAIL2BAN-KONFIGURATION AKTUALISIEREN"
    
    # Fail2ban-Status prüfen
    if systemctl is-active --quiet fail2ban; then
        print_info "Aktualisiere Fail2ban-Jails..."
        
        # Jail-Status abrufen
        local active_jails=$(sudo fail2ban-client status | grep "Jail list:" | cut -d: -f2 | tr ',' '\n' | xargs)
        
        for jail in $active_jails; do
            local banned_count=$(sudo fail2ban-client status "$jail" | grep "Currently banned:" | awk '{print $3}')
            print_info "Jail '$jail': $banned_count gesperrte IPs"
        done
        
        # Fail2ban neu laden
        print_info "Lade Fail2ban-Konfiguration neu..."
        sudo fail2ban-client reload
        print_success "Fail2ban-Konfiguration neu geladen"
    else
        print_warning "Fail2ban ist nicht aktiv"
    fi
}

# SSL-Zertifikate überprüfen
check_ssl_certificates() {
    print_header "SSL-ZERTIFIKATE ÜBERPRÜFEN"
    
    print_info "Prüfe SSL-Zertifikate..."
    
    # Lokale Zertifikate prüfen
    local cert_dirs=("/etc/ssl/certs" "/usr/share/ca-certificates")
    
    for cert_dir in "${cert_dirs[@]}"; do
        if [[ -d "$cert_dir" ]]; then
            local expired_certs=$(find "$cert_dir" -name "*.crt" -o -name "*.pem" | xargs -I {} sh -c 'openssl x509 -in {} -noout -checkend 2592000 2>/dev/null || echo {}' | grep -v "Certificate will not expire" || true)
            
            if [[ -n "$expired_certs" ]]; then
                print_warning "Abgelaufene oder bald ablaufende Zertifikate gefunden in $cert_dir"
            fi
        fi
    done
    
    # CA-Zertifikate aktualisieren
    print_info "Aktualisiere CA-Zertifikate..."
    sudo update-ca-certificates
    print_success "CA-Zertifikate aktualisiert"
}

# DNS-Konfiguration überprüfen
check_dns_configuration() {
    print_header "DNS-KONFIGURATION ÜBERPRÜFEN"
    
    if systemctl is-active --quiet unbound; then
        print_info "Teste DNS-Auflösung..."
        
        # DNS-Test
        if dig @127.0.0.1 google.com +short >/dev/null 2>&1; then
            print_success "DNS-Auflösung funktioniert"
        else
            print_warning "DNS-Auflösung hat Probleme"
        fi
        
        # DNSSEC-Test
        if dig @127.0.0.1 google.com +dnssec | grep -q "RRSIG"; then
            print_success "DNSSEC funktioniert"
        else
            print_warning "DNSSEC funktioniert möglicherweise nicht"
        fi
        
        # Root-Hints aktualisieren
        print_info "Aktualisiere DNS-Root-Hints..."
        if wget -q -O /tmp/named.root "https://www.internic.net/domain/named.root"; then
            sudo cp /tmp/named.root /var/lib/unbound/root.hints
            sudo systemctl reload unbound
            print_success "DNS-Root-Hints aktualisiert"
        else
            print_warning "Konnte DNS-Root-Hints nicht aktualisieren"
        fi
    else
        print_warning "Unbound ist nicht aktiv"
    fi
}

# Monitoring-Skripte aktualisieren
update_monitoring_scripts() {
    print_header "MONITORING-SKRIPTE AKTUALISIEREN"
    
    # Prüfe ob Playbook-Dateien verfügbar sind
    if [[ -d "$INSTALL_DIR" && -f "$INSTALL_DIR/manjaro_mitm_protection.yml" ]]; then
        print_info "Führe Ansible-Playbook für Updates aus..."
        cd "$INSTALL_DIR"
        
        # Nur Monitoring-relevante Tags ausführen
        if ansible-playbook --tags "scripts,validation" manjaro_mitm_protection.yml; then
            print_success "Monitoring-Skripte aktualisiert"
        else
            print_warning "Fehler beim Aktualisieren der Monitoring-Skripte"
        fi
    else
        print_warning "Ansible-Playbook nicht gefunden in $INSTALL_DIR"
    fi
}

# Log-Rotation überprüfen
check_log_rotation() {
    print_header "LOG-ROTATION ÜBERPRÜFEN"
    
    print_info "Überprüfe Log-Rotation-Konfiguration..."
    
    # Logrotate-Konfigurationen prüfen
    local logrotate_configs=(
        "/etc/logrotate.d/suricata"
        "/etc/logrotate.d/fail2ban"
        "/etc/logrotate.d/arpwatch"
    )
    
    for config in "${logrotate_configs[@]}"; do
        if [[ -f "$config" ]]; then
            print_success "Log-Rotation konfiguriert: $(basename "$config")"
        else
            print_warning "Log-Rotation fehlt: $(basename "$config")"
        fi
    done
    
    # Logrotate testen
    print_info "Teste Logrotate-Konfiguration..."
    sudo logrotate -d /etc/logrotate.conf >/dev/null 2>&1 && {
        print_success "Logrotate-Konfiguration ist gültig"
    } || {
        print_warning "Logrotate-Konfiguration hat Probleme"
    }
}

# Service-Status überprüfen
check_service_status() {
    print_header "SERVICE-STATUS ÜBERPRÜFEN"
    
    local services=("arpwatch" "suricata" "fail2ban" "unbound" "sshd")
    local failed_services=()
    
    for service in "${services[@]}"; do
        if systemctl is-active --quiet "$service"; then
            print_success "$service ist aktiv"
        else
            print_warning "$service ist nicht aktiv"
            failed_services+=("$service")
        fi
        
        if systemctl is-enabled --quiet "$service"; then
            print_info "$service ist aktiviert (startet beim Boot)"
        else
            print_warning "$service ist nicht aktiviert"
        fi
    done
    
    # Problematische Services neu starten
    if [[ ${#failed_services[@]} -gt 0 ]]; then
        read -p "Möchten Sie die inaktiven Services neu starten? (j/N): " restart_services
        if [[ "$restart_services" =~ ^[jJyY]$ ]]; then
            for service in "${failed_services[@]}"; do
                print_info "Starte $service neu..."
                sudo systemctl start "$service" && {
                    print_success "$service gestartet"
                } || {
                    print_error "Konnte $service nicht starten"
                }
            done
        fi
    fi
}

# Performance-Optimierung
optimize_performance() {
    print_header "PERFORMANCE-OPTIMIERUNG"
    
    print_info "Überprüfe Systemressourcen..."
    
    # RAM-Nutzung prüfen
    local ram_usage=$(free | awk 'NR==2{printf "%.0f", $3*100/$2}')
    print_info "RAM-Nutzung: ${ram_usage}%"
    
    if [[ $ram_usage -gt 80 ]]; then
        print_warning "Hohe RAM-Nutzung erkannt"
        print_info "Erwäge Suricata-Speicher-Limits zu reduzieren"
    fi
    
    # CPU-Last prüfen
    local cpu_load=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    print_info "CPU-Last: $cpu_load"
    
    # Disk-Space prüfen
    local disk_usage=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    print_info "Festplatten-Nutzung: ${disk_usage}%"
    
    if [[ $disk_usage -gt 90 ]]; then
        print_warning "Festplatte fast voll - Log-Bereinigung empfohlen"
    fi
    
    # Log-Größen prüfen
    print_info "Überprüfe Log-Datei-Größen..."
    local large_logs=$(find /var/log -name "*.log" -size +100M 2>/dev/null || true)
    if [[ -n "$large_logs" ]]; then
        print_warning "Große Log-Dateien gefunden:"
        echo "$large_logs" | while read -r logfile; do
            local size=$(du -h "$logfile" | cut -f1)
            echo "  - $logfile ($size)"
        done
    fi
}

# Sicherheits-Audit
security_audit() {
    print_header "SICHERHEITS-AUDIT"
    
    print_info "Führe Sicherheitsüberprüfung durch..."
    
    # SSH-Konfiguration prüfen
    local ssh_issues=()
    
    if grep -q "^Port 22" /etc/ssh/sshd_config 2>/dev/null; then
        ssh_issues+=("SSH läuft auf Standard-Port 22")
    fi
    
    if grep -q "^PasswordAuthentication yes" /etc/ssh/sshd_config 2>/dev/null; then
        ssh_issues+=("Passwort-Authentifizierung ist aktiviert")
    fi
    
    if grep -q "^PermitRootLogin yes" /etc/ssh/sshd_config 2>/dev/null; then
        ssh_issues+=("Root-Login ist erlaubt")
    fi
    
    if [[ ${#ssh_issues[@]} -gt 0 ]]; then
        print_warning "SSH-Sicherheitsprobleme gefunden:"
        for issue in "${ssh_issues[@]}"; do
            echo "  - $issue"
        done
    else
        print_success "SSH-Konfiguration ist sicher"
    fi
    
    # Firewall-Status prüfen
    if sudo ufw status | grep -q "Status: active"; then
        print_success "Firewall ist aktiv"
    else
        print_warning "Firewall ist nicht aktiv"
    fi
    
    # Offene Ports prüfen
    print_info "Überprüfe offene Ports..."
    local open_ports=$(ss -tuln | grep LISTEN | awk '{print $5}' | cut -d: -f2 | sort -n | uniq)
    print_info "Offene Ports: $(echo $open_ports | tr '\n' ' ')"
}

# Hauptfunktion
main() {
    clear
    print_header "MANJARO LINUX MITM PROTECTION UPDATER"
    
    cat << EOF
${BLUE}Dieses Skript aktualisiert alle MITM-Schutzkomponenten:${NC}

• System-Pakete aktualisieren
• Suricata-Regeln aktualisieren
• Fail2ban-Konfiguration überprüfen
• SSL-Zertifikate überprüfen
• DNS-Konfiguration testen
• Service-Status überprüfen
• Sicherheits-Audit durchführen

EOF
    
    read -p "Möchten Sie das Update starten? (j/N): " proceed
    if [[ ! "$proceed" =~ ^[jJyY]$ ]]; then
        print_info "Update abgebrochen."
        exit 0
    fi
    
    log "INFO" "MITM Protection Update gestartet"
    
    update_system_packages
    update_suricata_rules
    update_fail2ban_config
    check_ssl_certificates
    check_dns_configuration
    update_monitoring_scripts
    check_log_rotation
    check_service_status
    optimize_performance
    security_audit
    
    print_header "UPDATE ABGESCHLOSSEN"
    
    cat << EOF
${GREEN}✓ MITM-Schutz erfolgreich aktualisiert!${NC}

${BLUE}Durchgeführte Aktionen:${NC}
• System-Pakete aktualisiert
• Suricata-Regeln aktualisiert
• Konfigurationen überprüft
• Services überprüft
• Sicherheits-Audit durchgeführt

${BLUE}Empfehlungen:${NC}
• Führen Sie dieses Update-Skript regelmäßig aus
• Überwachen Sie die System-Logs
• Halten Sie Backups aktuell

${BLUE}Log-Datei:${NC} $LOG_FILE

EOF
    
    # Status-Check ausführen
    if [[ -f "/usr/local/bin/mitm-status" ]]; then
        print_info "Führe abschließenden Status-Check aus..."
        sudo /usr/local/bin/mitm-status
    fi
    
    log "INFO" "MITM Protection Update erfolgreich abgeschlossen"
}

# Skript ausführen
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi

