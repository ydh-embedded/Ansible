# MITM Protection Scripts - Verwendungsanleitung

## Übersicht der Skripte

Diese Sammlung enthält drei ausführbare Bash-Skripte für die vollständige Verwaltung des MITM-Schutzes auf Manjaro Linux:

### 1. `install-MITM-protection.sh` - Installationsskript
**Zweck**: Vollautomatische Installation aller MITM-Schutzkomponenten

**Funktionen**:
- Systemvoraussetzungen prüfen
- Benutzer-Konfiguration sammeln
- Alle notwendigen Pakete installieren
- Ansible-Playbook automatisch ausführen
- System-Backup erstellen
- Installation validieren

### 2. `update-MITM-protection.sh` - Update-Skript  
**Zweck**: Regelmäßige Updates und Wartung des MITM-Schutzes

**Funktionen**:
- System-Pakete aktualisieren
- Suricata-Regeln aktualisieren
- Konfigurationen überprüfen
- Service-Status prüfen
- Sicherheits-Audit durchführen
- Performance-Optimierung

### 3. `uninstall-MITM-protection.sh` - Deinstallationsskript
**Zweck**: Vollständige Entfernung aller MITM-Schutzkomponenten

**Funktionen**:
- Services stoppen und deaktivieren
- Konfigurationsdateien entfernen
- SSH-Konfiguration wiederherstellen
- Firewall zurücksetzen
- Optional: Pakete deinstallieren

---

## Verwendung

### Erstinstallation

```bash
# 1. Skript ausführbar machen (falls nötig)
chmod +x install-MITM-protection.sh

# 2. Installation starten
./install-MITM-protection.sh
```

**Interaktive Eingaben**:
- E-Mail-Adresse für Benachrichtigungen
- SSH-Port (Standard: 2222)
- Netzwerkschnittstelle (wird automatisch erkannt)

**Dauer**: 10-20 Minuten je nach System

### Regelmäßige Updates

```bash
# Update-Skript ausführen
./update-MITM-protection.sh
```

**Empfehlung**: Wöchentlich ausführen oder als Cron-Job einrichten:
```bash
# Wöchentliches Update jeden Sonntag um 3:00 Uhr
0 3 * * 0 /pfad/zum/update-MITM-protection.sh
```

### Deinstallation

```bash
# Deinstallation starten
./uninstall-MITM-protection.sh
```

**WARNUNG**: Entfernt alle Schutzmaßnahmen und stellt ursprüngliche Konfiguration wieder her.

---

## Detaillierte Funktionsbeschreibungen

### Installationsskript Features

#### Systemprüfung
- Manjaro/Arch Linux Erkennung
- Sudo-Berechtigung validieren
- Internetverbindung testen
- Speicherplatz prüfen (min. 5GB)
- RAM prüfen (empfohlen: 2GB+)

#### Automatische Konfiguration
- Netzwerkschnittstelle erkennen
- SSH-Port konfigurieren
- E-Mail-Benachrichtigungen einrichten
- Firewall-Regeln anpassen

#### Paket-Installation
**Basis-Pakete**:
- ansible, python, python-pip
- git, curl, wget, base-devel

**Sicherheits-Pakete**:
- arpwatch (ARP-Monitoring)
- suricata (IDS/IPS)
- fail2ban (Automatische Blockierung)
- ufw (Firewall)
- unbound (DNS-Sicherheit)
- tcpdump, wireshark-cli, nmap

#### Backup-Erstellung
Automatisches Backup von:
- SSH-Konfiguration
- Firewall-Regeln
- Systemd-Services
- Aktuelle iptables-Regeln

### Update-Skript Features

#### System-Updates
- Paketdatenbank aktualisieren
- Sicherheitspakete updaten
- Python-Abhängigkeiten prüfen

#### Regel-Updates
- Suricata Emerging Threats Rules
- Fail2ban Filter-Regeln
- DNS Root-Hints

#### Monitoring
- Service-Status überwachen
- Log-Rotation überprüfen
- Performance-Metriken sammeln
- SSL-Zertifikate validieren

#### Sicherheits-Audit
- SSH-Konfiguration prüfen
- Offene Ports scannen
- Firewall-Status validieren
- Schwachstellen identifizieren

### Deinstallationsskript Features

#### Service-Management
- Alle MITM-Services stoppen
- Systemd-Services deaktivieren
- Cron-Jobs entfernen

#### Konfiguration zurücksetzen
- SSH auf Port 22 zurücksetzen
- Passwort-Auth wieder aktivieren
- Firewall-Regeln löschen
- Kernel-Parameter zurücksetzen

#### Dateien bereinigen
- Konfigurationsverzeichnisse
- Log-Dateien
- Monitoring-Skripte
- Systemd-Service-Dateien

---

## Konfiguration und Anpassung

### Environment-Variablen

```bash
# E-Mail für Benachrichtigungen
export MITM_ADMIN_EMAIL="ihre-email@example.com"

# SSH-Port
export MITM_SSH_PORT="2222"

# Netzwerkschnittstelle
export MITM_INTERFACE="eth0"

# Log-Level
export MITM_LOG_LEVEL="INFO"
```

### Konfigurationsdateien

Nach der Installation finden Sie Konfigurationen in:
- `~/mitm-protection/` - Ansible-Playbook und Inventory
- `/etc/suricata/` - IDS-Konfiguration
- `/etc/fail2ban/` - Fail2ban-Regeln
- `/etc/unbound/` - DNS-Konfiguration

### Anpassung der Skripte

#### Zusätzliche Pakete installieren
Bearbeiten Sie in `install-MITM-protection.sh`:
```bash
local security_packages=(
    "arpwatch"
    "suricata"
    # Ihr zusätzliches Paket hier
    "ihr-paket"
)
```

#### Custom Suricata-Regeln
Fügen Sie in `templates/mitm-detection.rules.j2` hinzu:
```
alert tcp any any -> any 8080 (msg:"Custom Rule"; sid:3000001; rev:1;)
```

---

## Fehlerbehebung

### Häufige Probleme

#### 1. "Pacman nicht gefunden"
**Problem**: Skript läuft nicht auf Manjaro/Arch
**Lösung**: Nur auf Manjaro/Arch Linux verwenden

#### 2. "Sudo-Berechtigung fehlt"
**Problem**: Benutzer hat keine sudo-Rechte
**Lösung**: 
```bash
su -
usermod -aG wheel ihr_benutzername
```

#### 3. "Ansible-Playbook nicht gefunden"
**Problem**: Playbook-Dateien fehlen
**Lösung**: Alle Dateien in gleiches Verzeichnis kopieren

#### 4. "Service startet nicht"
**Problem**: Service-Konfiguration fehlerhaft
**Lösung**: 
```bash
sudo journalctl -u service_name
sudo systemctl status service_name
```

### Log-Dateien

Alle Skripte erstellen detaillierte Logs:
- Installation: `/tmp/mitm-protection-install.log`
- Update: `/tmp/mitm-protection-update.log`
- Deinstallation: `/tmp/mitm-protection-uninstall.log`

### Debug-Modus

Für detaillierte Ausgabe:
```bash
bash -x ./install-MITM-protection.sh
```

---

## Sicherheitshinweise

### Vor der Installation
1. **Backup erstellen**: System-Backup vor Installation
2. **SSH-Zugang sichern**: Stellen Sie sicher, dass Sie SSH-Zugang behalten
3. **Netzwerk-Zugang**: Prüfen Sie Firewall-Regeln vor Aktivierung

### Nach der Installation
1. **SSH-Port testen**: Neue SSH-Verbindung auf konfigurierten Port testen
2. **Service-Status prüfen**: Alle Services sollten aktiv sein
3. **E-Mail-Test**: Benachrichtigungen testen

### Wartung
1. **Regelmäßige Updates**: Wöchentlich Update-Skript ausführen
2. **Log-Monitoring**: Regelmäßig Logs auf Anomalien prüfen
3. **Backup-Rotation**: Alte Backups regelmäßig entfernen

---

## Support und Weiterentwicklung

### Logs analysieren
```bash
# Installation-Logs
tail -f /tmp/mitm-protection-install.log

# System-Logs
sudo journalctl -f -u arpwatch -u suricata -u fail2ban

# MITM-Status
sudo /usr/local/bin/mitm-status
```

### Konfiguration prüfen
```bash
# Ansible-Konfiguration testen
cd ~/mitm-protection
ansible-playbook --check manjaro_mitm_protection.yml

# Service-Status
systemctl status arpwatch suricata fail2ban unbound
```

### Performance-Monitoring
```bash
# Ressourcen-Verbrauch
htop

# Netzwerk-Traffic
sudo iftop -i eth0

# Disk-Usage
df -h
du -sh /var/log/*
```

---

## Automatisierung

### Cron-Jobs einrichten

```bash
# Crontab bearbeiten
crontab -e

# Wöchentliche Updates
0 3 * * 0 /pfad/zum/update-MITM-protection.sh

# Tägliche Status-Checks
0 6 * * * /usr/local/bin/mitm-status --report | mail -s "MITM Status" admin@example.com
```

### Systemd-Timer (Alternative zu Cron)

```bash
# Timer-Unit erstellen
sudo systemctl edit --force --full mitm-update.timer

# Service-Unit erstellen
sudo systemctl edit --force --full mitm-update.service

# Timer aktivieren
sudo systemctl enable --now mitm-update.timer
```

Diese Skripte bieten eine vollständige, benutzerfreundliche Lösung für den MITM-Schutz auf Manjaro Linux mit minimaler manueller Konfiguration.

