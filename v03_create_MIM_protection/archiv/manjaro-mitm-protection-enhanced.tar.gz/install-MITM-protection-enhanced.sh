#!/bin/bash

# =============================================================================
# MANJARO LINUX MITM PROTECTION INSTALLER (ENHANCED)
# =============================================================================
# Automatisches Installationsskript für umfassenden MITM-Schutz
# Unterstützt lokale und entfernte Installation
# Autor: Manus AI
# Version: 2.0
# Datum: 20. Juli 2025
# =============================================================================

set -euo pipefail  # Strict error handling

# =============================================================================
# KONFIGURATION UND VARIABLEN
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/tmp/mitm-protection-install.log"
BACKUP_DIR="/tmp/mitm-protection-backup-$(date +%Y%m%d-%H%M%S)"
INSTALL_DIR="$HOME/mitm-protection"

# Farben für Ausgabe
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Standard-Konfiguration
DEFAULT_EMAIL="admin@$(hostname -f)"
DEFAULT_SSH_PORT="2222"
DEFAULT_INTERFACE=""

# Ziel-Konfiguration
INSTALLATION_TYPE=""  # "local" oder "remote"
TARGET_HOSTS=()       # Array für Ziel-Hosts
SSH_USER=""           # SSH-Benutzer für entfernte Hosts
SSH_KEY_PATH=""       # Pfad zum SSH-Schlüssel

# =============================================================================
# HILFSFUNKTIONEN
# =============================================================================

# Logging-Funktion
log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" | tee -a "$LOG_FILE"
}

# Farbige Ausgabe
print_header() {
    echo -e "\n${PURPLE}==============================================================================${NC}"
    echo -e "${PURPLE}$1${NC}"
    echo -e "${PURPLE}==============================================================================${NC}\n"
}

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
    log "INFO" "$1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
    log "SUCCESS" "$1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
    log "WARNING" "$1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
    log "ERROR" "$1"
}

# Benutzer-Eingabe mit Validierung
get_user_input() {
    local prompt="$1"
    local default="$2"
    local validation_func="${3:-}"
    local input
    
    while true; do
        if [[ -n "$default" ]]; then
            read -p "$prompt [$default]: " input
            input="${input:-$default}"
        else
            read -p "$prompt: " input
        fi
        
        if [[ -z "$validation_func" ]] || $validation_func "$input"; then
            echo "$input"
            return 0
        else
            print_error "Ungültige Eingabe. Bitte versuchen Sie es erneut."
        fi
    done
}

# E-Mail-Validierung
validate_email() {
    local email="$1"
    if [[ "$email" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
        return 0
    else
        print_error "Ungültige E-Mail-Adresse."
        return 1
    fi
}

# Port-Validierung
validate_port() {
    local port="$1"
    if [[ "$port" =~ ^[0-9]+$ ]] && [ "$port" -ge 1024 ] && [ "$port" -le 65535 ]; then
        return 0
    else
        print_error "Port muss eine Zahl zwischen 1024 und 65535 sein."
        return 1
    fi
}

# IP-Adresse-Validierung
validate_ip() {
    local ip="$1"
    if [[ "$ip" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        local IFS='.'
        local -a octets=($ip)
        for octet in "${octets[@]}"; do
            if [[ $octet -gt 255 ]]; then
                print_error "Ungültige IP-Adresse: $ip"
                return 1
            fi
        done
        return 0
    else
        print_error "Ungültige IP-Adresse: $ip"
        return 1
    fi
}

# Hostname-Validierung
validate_hostname() {
    local hostname="$1"
    if [[ "$hostname" =~ ^[a-zA-Z0-9.-]+$ ]]; then
        return 0
    else
        print_error "Ungültiger Hostname: $hostname"
        return 1
    fi
}

# SSH-Verbindung testen
test_ssh_connection() {
    local host="$1"
    local user="$2"
    local key_path="$3"
    local port="${4:-22}"
    
    print_info "Teste SSH-Verbindung zu $user@$host:$port..."
    
    local ssh_opts="-o ConnectTimeout=10 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"
    
    if [[ -n "$key_path" ]]; then
        ssh_opts="$ssh_opts -i $key_path"
    fi
    
    if ssh $ssh_opts -p "$port" "$user@$host" "echo 'SSH-Verbindung erfolgreich'" 2>/dev/null; then
        print_success "SSH-Verbindung zu $host erfolgreich"
        return 0
    else
        print_error "SSH-Verbindung zu $host fehlgeschlagen"
        return 1
    fi
}

# Ziel-System prüfen
check_remote_system() {
    local host="$1"
    local user="$2"
    local key_path="$3"
    local port="${4:-22}"
    
    print_info "Überprüfe Ziel-System $host..."
    
    local ssh_opts="-o ConnectTimeout=10 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"
    
    if [[ -n "$key_path" ]]; then
        ssh_opts="$ssh_opts -i $key_path"
    fi
    
    # Manjaro/Arch Linux prüfen
    if ! ssh $ssh_opts -p "$port" "$user@$host" "command -v pacman" &>/dev/null; then
        print_error "$host ist kein Manjaro/Arch Linux System"
        return 1
    fi
    
    # Sudo-Berechtigung prüfen
    if ! ssh $ssh_opts -p "$port" "$user@$host" "sudo -n true" &>/dev/null; then
        print_warning "$user@$host benötigt Sudo-Berechtigung"
        print_info "Stelle sicher, dass der Benutzer sudo-Rechte hat oder NOPASSWD konfiguriert ist"
    fi
    
    print_success "Ziel-System $host ist kompatibel"
    return 0
}

# Installationstyp auswählen
select_installation_type() {
    print_header "INSTALLATIONSTYP AUSWÄHLEN"
    
    cat << EOF
${CYAN}Wählen Sie den Installationstyp:${NC}

${GREEN}1)${NC} Lokale Installation (auf diesem System)
${GREEN}2)${NC} Entfernte Installation (auf anderen Manjaro-Systemen)
${GREEN}3)${NC} Multi-Host Installation (mehrere Systeme gleichzeitig)

EOF
    
    while true; do
        read -p "Ihre Auswahl (1-3): " choice
        case $choice in
            1)
                INSTALLATION_TYPE="local"
                print_success "Lokale Installation ausgewählt"
                break
                ;;
            2)
                INSTALLATION_TYPE="remote"
                print_success "Entfernte Installation ausgewählt"
                break
                ;;
            3)
                INSTALLATION_TYPE="multi"
                print_success "Multi-Host Installation ausgewählt"
                break
                ;;
            *)
                print_error "Ungültige Auswahl. Bitte wählen Sie 1, 2 oder 3."
                ;;
        esac
    done
}

# SSH-Konfiguration für entfernte Hosts
configure_ssh_access() {
    print_header "SSH-ZUGANG KONFIGURIEREN"
    
    # SSH-Benutzer
    SSH_USER=$(get_user_input "SSH-Benutzername für Ziel-Hosts" "$(whoami)")
    
    # SSH-Schlüssel-Pfad
    local default_key="$HOME/.ssh/id_rsa"
    if [[ ! -f "$default_key" ]]; then
        default_key="$HOME/.ssh/id_ed25519"
    fi
    
    if [[ -f "$default_key" ]]; then
        SSH_KEY_PATH=$(get_user_input "Pfad zum SSH-Schlüssel" "$default_key")
    else
        print_warning "Kein SSH-Schlüssel gefunden"
        read -p "Möchten Sie einen SSH-Schlüssel generieren? (j/N): " generate_key
        
        if [[ "$generate_key" =~ ^[jJyY]$ ]]; then
            generate_ssh_key
        else
            SSH_KEY_PATH=$(get_user_input "Pfad zum SSH-Schlüssel" "")
        fi
    fi
    
    # SSH-Schlüssel validieren
    if [[ ! -f "$SSH_KEY_PATH" ]]; then
        print_error "SSH-Schlüssel nicht gefunden: $SSH_KEY_PATH"
        exit 1
    fi
    
    print_success "SSH-Konfiguration abgeschlossen"
}

# SSH-Schlüssel generieren
generate_ssh_key() {
    print_info "Generiere neuen SSH-Schlüssel..."
    
    local key_path="$HOME/.ssh/id_ed25519"
    local email=$(get_user_input "E-Mail für SSH-Schlüssel" "$(whoami)@$(hostname)")
    
    ssh-keygen -t ed25519 -C "$email" -f "$key_path" -N ""
    
    SSH_KEY_PATH="$key_path"
    print_success "SSH-Schlüssel generiert: $key_path"
    
    print_info "Öffentlicher Schlüssel:"
    cat "${key_path}.pub"
    echo
    print_warning "Kopieren Sie diesen Schlüssel auf die Ziel-Hosts mit:"
    print_info "ssh-copy-id -i ${key_path}.pub benutzer@ziel-host"
}

# Ziel-Hosts konfigurieren
configure_target_hosts() {
    print_header "ZIEL-HOSTS KONFIGURIEREN"
    
    case "$INSTALLATION_TYPE" in
        "local")
            TARGET_HOSTS=("localhost")
            print_info "Lokale Installation - keine weiteren Hosts erforderlich"
            ;;
        "remote")
            configure_single_remote_host
            ;;
        "multi")
            configure_multiple_hosts
            ;;
    esac
}

# Einzelnen entfernten Host konfigurieren
configure_single_remote_host() {
    print_info "Konfiguriere entfernten Host..."
    
    local host
    while true; do
        host=$(get_user_input "IP-Adresse oder Hostname des Ziel-Systems" "")
        
        if validate_ip "$host" || validate_hostname "$host"; then
            # SSH-Verbindung testen
            if test_ssh_connection "$host" "$SSH_USER" "$SSH_KEY_PATH"; then
                if check_remote_system "$host" "$SSH_USER" "$SSH_KEY_PATH"; then
                    TARGET_HOSTS=("$host")
                    break
                fi
            fi
        fi
        
        read -p "Möchten Sie einen anderen Host versuchen? (j/N): " retry
        if [[ ! "$retry" =~ ^[jJyY]$ ]]; then
            print_error "Installation abgebrochen"
            exit 1
        fi
    done
    
    print_success "Ziel-Host konfiguriert: $host"
}

# Mehrere Hosts konfigurieren
configure_multiple_hosts() {
    print_info "Konfiguriere mehrere Hosts..."
    
    local hosts_input
    hosts_input=$(get_user_input "Hosts (IP-Adressen/Hostnamen, getrennt durch Komma)" "")
    
    # Hosts in Array aufteilen
    IFS=',' read -ra ADDR <<< "$hosts_input"
    for host in "${ADDR[@]}"; do
        host=$(echo "$host" | xargs)  # Whitespace entfernen
        
        if validate_ip "$host" || validate_hostname "$host"; then
            print_info "Teste Host: $host"
            
            if test_ssh_connection "$host" "$SSH_USER" "$SSH_KEY_PATH"; then
                if check_remote_system "$host" "$SSH_USER" "$SSH_KEY_PATH"; then
                    TARGET_HOSTS+=("$host")
                    print_success "Host hinzugefügt: $host"
                else
                    print_warning "Host übersprungen (nicht kompatibel): $host"
                fi
            else
                print_warning "Host übersprungen (SSH-Fehler): $host"
            fi
        else
            print_warning "Host übersprungen (ungültig): $host"
        fi
    done
    
    if [[ ${#TARGET_HOSTS[@]} -eq 0 ]]; then
        print_error "Keine gültigen Hosts konfiguriert"
        exit 1
    fi
    
    print_success "${#TARGET_HOSTS[@]} Host(s) konfiguriert: ${TARGET_HOSTS[*]}"
}

# Systemvoraussetzungen prüfen
check_system_requirements() {
    print_header "SYSTEMVORAUSSETZUNGEN PRÜFEN"
    
    if [[ "$INSTALLATION_TYPE" == "local" ]]; then
        check_local_requirements
    else
        check_remote_requirements
    fi
}

# Lokale Systemvoraussetzungen
check_local_requirements() {
    # Manjaro/Arch Linux prüfen
    if ! command -v pacman &> /dev/null; then
        print_error "Dieses Skript ist nur für Manjaro/Arch Linux geeignet."
        exit 1
    fi
    
    print_success "Manjaro/Arch Linux erkannt"
    
    # Root-Rechte prüfen
    if [[ $EUID -eq 0 ]]; then
        print_error "Dieses Skript sollte NICHT als root ausgeführt werden."
        print_info "Führen Sie es als normaler Benutzer aus. Sudo wird bei Bedarf verwendet."
        exit 1
    fi
    
    # Sudo-Berechtigung prüfen
    if ! sudo -n true 2>/dev/null; then
        print_info "Sudo-Berechtigung erforderlich. Bitte geben Sie Ihr Passwort ein:"
        sudo -v || {
            print_error "Sudo-Berechtigung erforderlich für die Installation."
            exit 1
        }
    fi
    
    print_success "Sudo-Berechtigung bestätigt"
    
    # Weitere lokale Prüfungen...
    check_common_requirements
}

# Entfernte Systemvoraussetzungen
check_remote_requirements() {
    print_info "Prüfe Control Node (lokales System)..."
    
    # Ansible auf Control Node installieren
    if ! command -v ansible &> /dev/null; then
        print_info "Installiere Ansible auf Control Node..."
        if command -v pacman &> /dev/null; then
            sudo pacman -S --noconfirm ansible
        elif command -v apt &> /dev/null; then
            sudo apt update && sudo apt install -y ansible
        elif command -v yum &> /dev/null; then
            sudo yum install -y ansible
        else
            print_error "Konnte Ansible nicht automatisch installieren"
            print_info "Bitte installieren Sie Ansible manuell"
            exit 1
        fi
    fi
    
    print_success "Ansible verfügbar"
    
    # SSH-Agent starten
    if [[ -z "${SSH_AUTH_SOCK:-}" ]]; then
        print_info "Starte SSH-Agent..."
        eval $(ssh-agent -s)
        ssh-add "$SSH_KEY_PATH"
    fi
    
    check_common_requirements
}

# Gemeinsame Systemvoraussetzungen
check_common_requirements() {
    # Internetverbindung prüfen
    if ! ping -c 1 8.8.8.8 &> /dev/null; then
        print_error "Keine Internetverbindung verfügbar."
        exit 1
    fi
    
    print_success "Internetverbindung verfügbar"
    
    # Speicherplatz prüfen (mindestens 2GB für Control Node)
    local available_space=$(df / | awk 'NR==2 {print $4}')
    local required_space=2097152  # 2GB in KB
    
    if [[ $available_space -lt $required_space ]]; then
        print_error "Nicht genügend Speicherplatz. Mindestens 2GB erforderlich."
        exit 1
    fi
    
    print_success "Ausreichend Speicherplatz verfügbar"
}

# Netzwerkschnittstelle automatisch erkennen
detect_network_interface() {
    if [[ "$INSTALLATION_TYPE" == "local" ]]; then
        print_info "Erkenne Hauptnetzwerkschnittstelle..."
        
        # Aktive Schnittstelle mit Default-Route finden
        local interface=$(ip route | grep '^default' | head -1 | awk '{print $5}')
        
        if [[ -n "$interface" ]]; then
            print_success "Hauptnetzwerkschnittstelle erkannt: $interface"
            DEFAULT_INTERFACE="$interface"
        else
            print_warning "Konnte Hauptnetzwerkschnittstelle nicht automatisch erkennen."
            print_info "Verfügbare Netzwerkschnittstellen:"
            ip link show | grep -E '^[0-9]+:' | awk -F': ' '{print "  - " $2}' | sed 's/@.*//'
        fi
    fi
}

# Benutzer-Konfiguration sammeln
collect_user_configuration() {
    print_header "KONFIGURATION"
    
    print_info "Bitte geben Sie die folgenden Informationen ein:"
    echo
    
    # E-Mail-Adresse
    ADMIN_EMAIL=$(get_user_input "E-Mail-Adresse für Benachrichtigungen" "$DEFAULT_EMAIL" "validate_email")
    
    # SSH-Port
    SSH_PORT=$(get_user_input "SSH-Port (wird von 22 geändert)" "$DEFAULT_SSH_PORT" "validate_port")
    
    # Netzwerkschnittstelle (nur für lokale Installation)
    if [[ "$INSTALLATION_TYPE" == "local" ]]; then
        if [[ -n "$DEFAULT_INTERFACE" ]]; then
            NETWORK_INTERFACE=$(get_user_input "Hauptnetzwerkschnittstelle" "$DEFAULT_INTERFACE")
        else
            NETWORK_INTERFACE=$(get_user_input "Hauptnetzwerkschnittstelle (z.B. eth0, enp0s3)" "")
        fi
    else
        NETWORK_INTERFACE="auto"  # Wird auf Ziel-Hosts automatisch erkannt
    fi
    
    # Bestätigung anzeigen
    echo
    print_info "Konfiguration:"
    echo "  Installationstyp:     $INSTALLATION_TYPE"
    echo "  Ziel-Host(s):         ${TARGET_HOSTS[*]}"
    if [[ "$INSTALLATION_TYPE" != "local" ]]; then
        echo "  SSH-Benutzer:         $SSH_USER"
        echo "  SSH-Schlüssel:        $SSH_KEY_PATH"
    fi
    echo "  E-Mail:               $ADMIN_EMAIL"
    echo "  SSH-Port:             $SSH_PORT"
    if [[ "$INSTALLATION_TYPE" == "local" ]]; then
        echo "  Netzwerkschnittstelle: $NETWORK_INTERFACE"
    fi
    echo
    
    read -p "Ist diese Konfiguration korrekt? (j/N): " confirm
    if [[ ! "$confirm" =~ ^[jJyY]$ ]]; then
        print_info "Installation abgebrochen."
        exit 0
    fi
}

# System-Backup erstellen
create_system_backup() {
    print_header "SYSTEM-BACKUP ERSTELLEN"
    
    print_info "Erstelle Backup wichtiger Konfigurationsdateien..."
    mkdir -p "$BACKUP_DIR"
    
    if [[ "$INSTALLATION_TYPE" == "local" ]]; then
        # Lokales Backup
        create_local_backup
    else
        # Entferntes Backup
        create_remote_backup
    fi
    
    print_success "Backup erstellt in: $BACKUP_DIR"
}

# Lokales Backup
create_local_backup() {
    # SSH-Konfiguration
    if [[ -f /etc/ssh/sshd_config ]]; then
        sudo cp /etc/ssh/sshd_config "$BACKUP_DIR/sshd_config.backup"
        print_success "SSH-Konfiguration gesichert"
    fi
    
    # Firewall-Status
    sudo ufw status > "$BACKUP_DIR/ufw_status.backup" 2>/dev/null || true
    
    # Aktuelle iptables-Regeln
    sudo iptables-save > "$BACKUP_DIR/iptables.backup" 2>/dev/null || true
    
    # Systemd-Services
    systemctl list-unit-files --state=enabled > "$BACKUP_DIR/enabled_services.backup"
}

# Entferntes Backup
create_remote_backup() {
    for host in "${TARGET_HOSTS[@]}"; do
        print_info "Erstelle Backup für Host: $host"
        
        local host_backup_dir="$BACKUP_DIR/$host"
        mkdir -p "$host_backup_dir"
        
        local ssh_opts="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"
        if [[ -n "$SSH_KEY_PATH" ]]; then
            ssh_opts="$ssh_opts -i $SSH_KEY_PATH"
        fi
        
        # SSH-Konfiguration
        ssh $ssh_opts "$SSH_USER@$host" "sudo cat /etc/ssh/sshd_config" > "$host_backup_dir/sshd_config.backup" 2>/dev/null || true
        
        # Firewall-Status
        ssh $ssh_opts "$SSH_USER@$host" "sudo ufw status" > "$host_backup_dir/ufw_status.backup" 2>/dev/null || true
        
        print_success "Backup für $host erstellt"
    done
}

# Ansible-Konfiguration erstellen
setup_ansible_configuration() {
    print_header "ANSIBLE-KONFIGURATION ERSTELLEN"
    
    # Arbeitsverzeichnis erstellen
    mkdir -p "$INSTALL_DIR"
    cd "$INSTALL_DIR"
    
    # Inventory-Datei erstellen
    create_ansible_inventory
    
    # Ansible-Konfigurationsdatei
    create_ansible_config
    
    print_success "Ansible-Konfiguration erstellt"
}

# Ansible-Inventory erstellen
create_ansible_inventory() {
    print_info "Erstelle Ansible-Inventory..."
    
    cat > inventory.ini << EOF
# Ansible Inventory für Manjaro MITM Protection
[manjaro_hosts]
EOF
    
    if [[ "$INSTALLATION_TYPE" == "local" ]]; then
        cat >> inventory.ini << EOF
localhost ansible_connection=local
EOF
    else
        for host in "${TARGET_HOSTS[@]}"; do
            cat >> inventory.ini << EOF
$host ansible_host=$host ansible_user=$SSH_USER ansible_ssh_private_key_file=$SSH_KEY_PATH
EOF
        done
    fi
    
    cat >> inventory.ini << EOF

[manjaro_hosts:vars]
ansible_become=yes
ansible_become_method=sudo
ansible_python_interpreter=/usr/bin/python3
ansible_ssh_common_args='-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null'

# MITM Protection Konfiguration
admin_email=$ADMIN_EMAIL
primary_interface=$NETWORK_INTERFACE
ssh_port=$SSH_PORT
alert_threshold_arp=3
alert_threshold_dns=5
log_retention_days=30
EOF
    
    print_success "Inventory-Datei erstellt: $INSTALL_DIR/inventory.ini"
}

# Ansible-Konfiguration erstellen
create_ansible_config() {
    print_info "Erstelle Ansible-Konfiguration..."
    
    cat > ansible.cfg << EOF
[defaults]
inventory = inventory.ini
host_key_checking = False
timeout = 30
gathering = smart
fact_caching = memory
stdout_callback = yaml
bin_ansible_callbacks = True
retry_files_enabled = False

[ssh_connection]
ssh_args = -o ControlMaster=auto -o ControlPersist=60s -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no
pipelining = True
control_path = /tmp/ansible-ssh-%%h-%%p-%%r
EOF
    
    print_success "Ansible-Konfiguration erstellt"
}

# Pakete installieren (nur für lokale Installation)
install_packages() {
    if [[ "$INSTALLATION_TYPE" != "local" ]]; then
        print_info "Paket-Installation wird über Ansible auf Ziel-Hosts durchgeführt"
        return 0
    fi
    
    print_header "PAKETE INSTALLIEREN"
    
    print_info "Aktualisiere Paketdatenbank..."
    sudo pacman -Sy --noconfirm
    
    print_info "Installiere Basis-Pakete..."
    local base_packages=(
        "ansible"
        "python"
        "python-pip"
        "python-yaml"
        "python-jinja"
        "git"
        "curl"
        "wget"
        "base-devel"
    )
    
    for package in "${base_packages[@]}"; do
        if ! pacman -Qi "$package" &>/dev/null; then
            print_info "Installiere $package..."
            sudo pacman -S --noconfirm "$package" || {
                print_error "Fehler beim Installieren von $package"
                exit 1
            }
        else
            print_info "$package ist bereits installiert"
        fi
    done
    
    print_success "Basis-Pakete installiert"
}

# Playbook-Dateien kopieren
copy_playbook_files() {
    print_header "PLAYBOOK-DATEIEN KOPIEREN"
    
    if [[ -f "$SCRIPT_DIR/manjaro_mitm_protection.yml" ]]; then
        print_info "Kopiere Playbook-Dateien..."
        cp "$SCRIPT_DIR/manjaro_mitm_protection.yml" "$INSTALL_DIR/"
        
        if [[ -d "$SCRIPT_DIR/templates" ]]; then
            cp -r "$SCRIPT_DIR/templates" "$INSTALL_DIR/"
            print_success "Template-Dateien kopiert"
        fi
        
        if [[ -f "$SCRIPT_DIR/README.md" ]]; then
            cp "$SCRIPT_DIR/README.md" "$INSTALL_DIR/"
        fi
        
        if [[ -f "$SCRIPT_DIR/INSTALL.md" ]]; then
            cp "$SCRIPT_DIR/INSTALL.md" "$INSTALL_DIR/"
        fi
        
        print_success "Playbook-Dateien kopiert nach: $INSTALL_DIR"
    else
        print_error "Playbook-Dateien nicht gefunden in: $SCRIPT_DIR"
        print_info "Stelle sicher, dass alle Dateien im gleichen Verzeichnis sind."
        exit 1
    fi
}

# SSH-Schlüssel auf Ziel-Hosts verteilen
distribute_ssh_keys() {
    if [[ "$INSTALLATION_TYPE" == "local" ]]; then
        return 0
    fi
    
    print_header "SSH-SCHLÜSSEL VERTEILEN"
    
    for host in "${TARGET_HOSTS[@]}"; do
        print_info "Überprüfe SSH-Zugang zu $host..."
        
        if ! test_ssh_connection "$host" "$SSH_USER" "$SSH_KEY_PATH"; then
            print_warning "SSH-Schlüssel für $host nicht konfiguriert"
            
            read -p "Möchten Sie den SSH-Schlüssel automatisch kopieren? (j/N): " copy_key
            if [[ "$copy_key" =~ ^[jJyY]$ ]]; then
                print_info "Kopiere SSH-Schlüssel zu $host..."
                ssh-copy-id -i "${SSH_KEY_PATH}.pub" "$SSH_USER@$host" || {
                    print_error "Fehler beim Kopieren des SSH-Schlüssels zu $host"
                    print_info "Bitte kopieren Sie den Schlüssel manuell:"
                    print_info "ssh-copy-id -i ${SSH_KEY_PATH}.pub $SSH_USER@$host"
                    exit 1
                }
                print_success "SSH-Schlüssel zu $host kopiert"
            else
                print_error "SSH-Zugang zu $host erforderlich"
                exit 1
            fi
        else
            print_success "SSH-Zugang zu $host bereits konfiguriert"
        fi
    done
}

# Ansible-Playbook ausführen
run_ansible_playbook() {
    print_header "MITM-SCHUTZ INSTALLIEREN"
    
    cd "$INSTALL_DIR"
    
    print_info "Führe Ansible-Playbook aus..."
    print_warning "Dies kann einige Minuten dauern..."
    
    # Playbook-Syntax prüfen
    print_info "Prüfe Playbook-Syntax..."
    if ! ansible-playbook --syntax-check manjaro_mitm_protection.yml; then
        print_error "Syntax-Fehler im Playbook"
        exit 1
    fi
    
    print_success "Playbook-Syntax ist korrekt"
    
    # Ansible-Verbindung testen
    print_info "Teste Ansible-Verbindungen..."
    if ! ansible manjaro_hosts -m ping; then
        print_error "Ansible-Verbindung fehlgeschlagen"
        print_info "Prüfen Sie SSH-Zugang und Inventory-Konfiguration"
        exit 1
    fi
    
    print_success "Ansible-Verbindungen erfolgreich"
    
    # Trockenlauf
    print_info "Führe Trockenlauf durch..."
    if ! ansible-playbook --check manjaro_mitm_protection.yml; then
        print_warning "Trockenlauf zeigte Probleme - Installation wird trotzdem fortgesetzt"
    else
        print_success "Trockenlauf erfolgreich"
    fi
    
    # Tatsächliche Installation
    print_info "Starte Installation auf ${#TARGET_HOSTS[@]} Host(s)..."
    if ansible-playbook manjaro_mitm_protection.yml; then
        print_success "MITM-Schutz erfolgreich installiert!"
    else
        print_error "Fehler bei der Installation"
        print_info "Prüfe die Logs für Details: $LOG_FILE"
        exit 1
    fi
}

# System-Status überprüfen
verify_installation() {
    print_header "INSTALLATION ÜBERPRÜFEN"
    
    print_info "Überprüfe installierte Services auf allen Hosts..."
    
    cd "$INSTALL_DIR"
    
    # Service-Status auf allen Hosts prüfen
    local services=("arpwatch" "suricata" "fail2ban" "unbound" "sshd")
    
    for service in "${services[@]}"; do
        print_info "Prüfe Service: $service"
        ansible manjaro_hosts -m systemd -a "name=$service state=started" --check || {
            print_warning "$service läuft möglicherweise nicht auf allen Hosts"
        }
    done
    
    # MITM-Status-Skript ausführen
    print_info "Führe MITM-Status-Check auf allen Hosts aus..."
    ansible manjaro_hosts -m shell -a "/usr/local/bin/mitm-status" --become || {
        print_warning "Status-Check zeigte Probleme auf einigen Hosts"
    }
    
    print_success "Installation-Überprüfung abgeschlossen"
}

# Abschließende Informationen
show_final_information() {
    print_header "INSTALLATION ABGESCHLOSSEN"
    
    cat << EOF
${GREEN}✓ MITM-Schutz erfolgreich installiert!${NC}

${YELLOW}INSTALLATIONSDETAILS:${NC}
  Installationstyp: ${CYAN}$INSTALLATION_TYPE${NC}
  Anzahl Hosts: ${CYAN}${#TARGET_HOSTS[@]}${NC}
  Ziel-Host(s): ${CYAN}${TARGET_HOSTS[*]}${NC}

${YELLOW}WICHTIGE INFORMATIONEN:${NC}

${BLUE}SSH-Zugang:${NC}
  - SSH läuft jetzt auf Port: ${YELLOW}$SSH_PORT${NC}
EOF

    if [[ "$INSTALLATION_TYPE" == "local" ]]; then
        cat << EOF
  - Lokale Verbindung: ${CYAN}ssh -p $SSH_PORT $(whoami)@localhost${NC}
EOF
    else
        cat << EOF
  - Entfernte Verbindung: ${CYAN}ssh -p $SSH_PORT $SSH_USER@HOST${NC}
EOF
    fi

    cat << EOF
  - Passwort-Authentifizierung ist deaktiviert

${BLUE}Installierte Services (auf allen Hosts):${NC}
  - Arpwatch (ARP-Monitoring)
  - Suricata (Intrusion Detection)
  - Fail2ban (Automatische Blockierung)
  - Unbound (Sicherer DNS)
  - UFW (Firewall)

${BLUE}Monitoring:${NC}
EOF

    if [[ "$INSTALLATION_TYPE" == "local" ]]; then
        cat << EOF
  - Status prüfen: ${CYAN}sudo /usr/local/bin/mitm-status${NC}
  - Logs anzeigen: ${CYAN}sudo journalctl -f -u arpwatch -u suricata -u fail2ban${NC}
EOF
    else
        cat << EOF
  - Status prüfen: ${CYAN}ansible manjaro_hosts -m shell -a "/usr/local/bin/mitm-status" --become${NC}
  - Logs anzeigen: ${CYAN}ansible manjaro_hosts -m shell -a "journalctl -f -u arpwatch -u suricata -u fail2ban" --become${NC}
EOF
    fi

    cat << EOF

${BLUE}Konfiguration:${NC}
  - Installationsverzeichnis: ${YELLOW}$INSTALL_DIR${NC}
  - Backup-Verzeichnis: ${YELLOW}$BACKUP_DIR${NC}
  - Log-Datei: ${YELLOW}$LOG_FILE${NC}
  - Ansible-Inventory: ${YELLOW}$INSTALL_DIR/inventory.ini${NC}

${BLUE}E-Mail-Benachrichtigungen:${NC}
  - Konfiguriert für: ${YELLOW}$ADMIN_EMAIL${NC}
  - Für funktionsfähige E-Mails konfigurieren Sie einen Mail-Server auf den Ziel-Hosts

${YELLOW}NÄCHSTE SCHRITTE:${NC}
1. Testen Sie die SSH-Verbindung auf Port $SSH_PORT
2. Überprüfen Sie die Service-Status auf allen Hosts
3. Konfigurieren Sie E-Mail-Benachrichtigungen
4. Lesen Sie die Dokumentation in $INSTALL_DIR

${YELLOW}WARTUNG:${NC}
- Updates: ${CYAN}ansible-playbook manjaro_mitm_protection.yml${NC}
- Status: ${CYAN}ansible manjaro_hosts -m shell -a "/usr/local/bin/mitm-status" --become${NC}

${RED}WARNUNG:${NC}
- SSH läuft jetzt auf Port $SSH_PORT statt 22 (auf allen Hosts)
- Stellen Sie sicher, dass Sie sich zu allen Hosts verbinden können
- Bei Problemen: Backup in $BACKUP_DIR verfügbar

EOF
}

# Fehlerbehandlung
cleanup_on_error() {
    print_error "Installation fehlgeschlagen!"
    print_info "Backup verfügbar in: $BACKUP_DIR"
    print_info "Log-Datei: $LOG_FILE"
    
    read -p "Möchten Sie die Änderungen rückgängig machen? (j/N): " rollback
    if [[ "$rollback" =~ ^[jJyY]$ ]]; then
        print_info "Führe Rollback durch..."
        
        if [[ "$INSTALLATION_TYPE" == "local" ]]; then
            # Lokales Rollback
            if [[ -f "$BACKUP_DIR/sshd_config.backup" ]]; then
                sudo cp "$BACKUP_DIR/sshd_config.backup" /etc/ssh/sshd_config
                sudo systemctl restart sshd
                print_success "SSH-Konfiguration wiederhergestellt"
            fi
        else
            # Entferntes Rollback
            for host in "${TARGET_HOSTS[@]}"; do
                if [[ -f "$BACKUP_DIR/$host/sshd_config.backup" ]]; then
                    print_info "Stelle SSH-Konfiguration für $host wieder her..."
                    local ssh_opts="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"
                    if [[ -n "$SSH_KEY_PATH" ]]; then
                        ssh_opts="$ssh_opts -i $SSH_KEY_PATH"
                    fi
                    
                    scp $ssh_opts "$BACKUP_DIR/$host/sshd_config.backup" "$SSH_USER@$host:/tmp/sshd_config.backup"
                    ssh $ssh_opts "$SSH_USER@$host" "sudo cp /tmp/sshd_config.backup /etc/ssh/sshd_config && sudo systemctl restart sshd"
                    print_success "SSH-Konfiguration für $host wiederhergestellt"
                fi
            done
        fi
        
        print_success "Rollback abgeschlossen"
    fi
    
    exit 1
}

# =============================================================================
# HAUPTPROGRAMM
# =============================================================================

main() {
    # Fehlerbehandlung einrichten
    trap cleanup_on_error ERR
    
    # Header anzeigen
    clear
    print_header "MANJARO LINUX MITM PROTECTION INSTALLER (ENHANCED)"
    
    cat << EOF
${CYAN}Willkommen zum erweiterten MITM-Schutz-Installer!${NC}

Dieses Skript unterstützt:
${GREEN}•${NC} Lokale Installation (auf diesem System)
${GREEN}•${NC} Entfernte Installation (auf anderen Manjaro-Systemen)
${GREEN}•${NC} Multi-Host Installation (mehrere Systeme gleichzeitig)

Installierte Komponenten:
• Arpwatch (ARP-Spoofing-Erkennung)
• Suricata (Intrusion Detection System)
• Fail2ban (Automatische Bedrohungsabwehr)
• Unbound (Sicherer DNS-Resolver)
• UFW (Firewall-Konfiguration)
• SSH-Sicherheitshärtung

${YELLOW}WARNUNG: Dieses Skript wird Systemkonfigurationen ändern!${NC}
Ein Backup wird automatisch erstellt.

EOF
    
    read -p "Möchten Sie fortfahren? (j/N): " proceed
    if [[ ! "$proceed" =~ ^[jJyY]$ ]]; then
        print_info "Installation abgebrochen."
        exit 0
    fi
    
    # Installationsschritte ausführen
    log "INFO" "MITM Protection Installation gestartet"
    
    select_installation_type
    
    if [[ "$INSTALLATION_TYPE" != "local" ]]; then
        configure_ssh_access
    fi
    
    configure_target_hosts
    check_system_requirements
    detect_network_interface
    collect_user_configuration
    create_system_backup
    install_packages
    setup_ansible_configuration
    copy_playbook_files
    
    if [[ "$INSTALLATION_TYPE" != "local" ]]; then
        distribute_ssh_keys
    fi
    
    run_ansible_playbook
    verify_installation
    show_final_information
    
    log "INFO" "MITM Protection Installation erfolgreich abgeschlossen"
    print_success "Installation erfolgreich abgeschlossen!"
}

# Skript ausführen
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi

