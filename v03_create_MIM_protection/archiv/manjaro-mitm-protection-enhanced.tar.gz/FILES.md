# Manjaro MITM Protection - Dateiübersicht

## Hauptdateien

### Ansible Playbook
- `manjaro_mitm_protection.yml` - Hauptplaybook für MITM-Schutz
- `inventory.ini` - Ansible-Inventory-Konfiguration

### Dokumentation
- `README.md` - Hauptdokumentation und Übersicht
- `INSTALL.md` - Detaillierte Installationsanleitung
- `FILES.md` - Diese Dateiübersicht

### Zusätzliche Dokumentation
- `Ansible_MITM_Schutz_Tools.md` - Umfassende Dokumentation verfügbarer Ansible-Tools
- `MITM_Schutz_Leitfaden.md` - Allgemeiner MITM-Schutz-Leitfaden

## Template-Dateien (templates/)

### Netzwerk-Monitoring
- `arpwatch.conf.j2` - Arpwatch-Konfiguration
- `arpwatch.service.j2` - Systemd-Service für Arpwatch
- `network-monitor.py.j2` - Python-Netzwerk-Monitoring-Skript

### Intrusion Detection
- `suricata.yaml.j2` - Suricata IDS-Hauptkonfiguration
- `mitm-detection.rules.j2` - Benutzerdefinierte MITM-Erkennungsregeln

### Fail2Ban-Konfiguration
- `fail2ban-mitm.conf.j2` - Hauptkonfiguration für Fail2Ban
- `arp-spoofing.conf.j2` - Filter für ARP-Spoofing-Erkennung
- `dns-spoofing.conf.j2` - Filter für DNS-Spoofing-Erkennung
- `ssl-mitm.conf.j2` - Filter für SSL-MITM-Erkennung

### DNS-Sicherheit
- `unbound.conf.j2` - Unbound DNS-Resolver-Konfiguration

### Monitoring und Status
- `mitm-status.py.j2` - Status-Überprüfungsskript
- `mitm-monitor.service.j2` - Systemd-Service für kontinuierliches Monitoring

## Verwendung

### Schnellstart
```bash
# 1. Inventory anpassen
nano inventory.ini

# 2. Playbook ausführen
ansible-playbook -i inventory.ini manjaro_mitm_protection.yml

# 3. Status überprüfen
sudo /usr/local/bin/mitm-status
```

### Anpassung
- Bearbeiten Sie die Template-Dateien für spezifische Konfigurationen
- Passen Sie Variablen in `inventory.ini` an
- Erweitern Sie das Hauptplaybook für zusätzliche Funktionen

### Tags verfügbar
- `preparation` - Systemvorbereitung
- `monitoring` - Netzwerk-Monitoring (Arpwatch)
- `ids` - Intrusion Detection System (Suricata)
- `firewall` - Firewall-Konfiguration (UFW)
- `ssh` - SSH-Sicherheitshärtung
- `fail2ban` - Fail2Ban-Konfiguration
- `ssl` - SSL/TLS-Sicherheit
- `dns` - DNS-Sicherheitskonfiguration
- `scripts` - Monitoring-Skripte
- `logging` - Logging und Alerting
- `hardening` - System-Härtung
- `validation` - Abschließende Validierung

### Beispiel für selektive Ausführung
```bash
# Nur Monitoring und IDS installieren
ansible-playbook -i inventory.ini manjaro_mitm_protection.yml --tags "monitoring,ids"

# Nur SSH-Härtung
ansible-playbook -i inventory.ini manjaro_mitm_protection.yml --tags "ssh"
```

## Systemanforderungen

- Manjaro Linux (alle Editionen)
- Ansible 2.9+
- Python 3.8+
- Sudo-Berechtigung
- Mindestens 2 GB RAM
- 5 GB freier Speicherplatz

## Support

Für Unterstützung und Fehlerbehebung siehe:
- `README.md` für allgemeine Informationen
- `INSTALL.md` für detaillierte Installationshilfe
- Log-Dateien in `/var/log/` für Diagnose

