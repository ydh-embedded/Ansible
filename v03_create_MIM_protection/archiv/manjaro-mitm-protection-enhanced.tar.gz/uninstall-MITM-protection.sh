#!/bin/bash

# =============================================================================
# MANJARO LINUX MITM PROTECTION UNINSTALLER
# =============================================================================
# Deinstallationsskript für MITM-Schutz
# Autor: Manus AI
# Version: 1.0
# =============================================================================

set -euo pipefail

# Farben
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

LOG_FILE="/tmp/mitm-protection-uninstall.log"

# Logging-Funktion
log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" | tee -a "$LOG_FILE"
}

print_header() {
    echo -e "\n${BLUE}==============================================================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}==============================================================================${NC}\n"
}

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
    log "INFO" "$1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
    log "SUCCESS" "$1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
    log "WARNING" "$1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
    log "ERROR" "$1"
}

# Services stoppen und deaktivieren
stop_services() {
    print_header "SERVICES STOPPEN"
    
    local services=("arpwatch" "suricata" "fail2ban" "mitm-monitor")
    
    for service in "${services[@]}"; do
        if systemctl is-active --quiet "$service" 2>/dev/null; then
            print_info "Stoppe $service..."
            sudo systemctl stop "$service"
            print_success "$service gestoppt"
        fi
        
        if systemctl is-enabled --quiet "$service" 2>/dev/null; then
            print_info "Deaktiviere $service..."
            sudo systemctl disable "$service"
            print_success "$service deaktiviert"
        fi
    done
}

# Firewall-Regeln zurücksetzen
reset_firewall() {
    print_header "FIREWALL ZURÜCKSETZEN"
    
    print_info "Setze UFW-Firewall zurück..."
    sudo ufw --force reset
    sudo ufw disable
    print_success "Firewall zurückgesetzt"
}

# SSH-Konfiguration wiederherstellen
restore_ssh_config() {
    print_header "SSH-KONFIGURATION WIEDERHERSTELLEN"
    
    # Backup suchen
    local backup_files=(
        "/tmp/mitm-protection-backup-*/sshd_config.backup"
        "/etc/ssh/sshd_config.backup"
    )
    
    local backup_found=false
    for backup_pattern in "${backup_files[@]}"; do
        for backup_file in $backup_pattern; do
            if [[ -f "$backup_file" ]]; then
                print_info "Stelle SSH-Konfiguration wieder her von: $backup_file"
                sudo cp "$backup_file" /etc/ssh/sshd_config
                sudo systemctl restart sshd
                print_success "SSH-Konfiguration wiederhergestellt"
                backup_found=true
                break 2
            fi
        done
    done
    
    if [[ "$backup_found" == false ]]; then
        print_warning "Kein SSH-Backup gefunden. Setze auf Standard-Konfiguration zurück..."
        
        # Standard SSH-Konfiguration wiederherstellen
        sudo sed -i 's/^Port .*/Port 22/' /etc/ssh/sshd_config
        sudo sed -i 's/^PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
        sudo sed -i 's/^PermitRootLogin no/PermitRootLogin yes/' /etc/ssh/sshd_config
        sudo systemctl restart sshd
        
        print_success "SSH auf Standard-Konfiguration zurückgesetzt"
    fi
}

# Konfigurationsdateien entfernen
remove_config_files() {
    print_header "KONFIGURATIONSDATEIEN ENTFERNEN"
    
    local config_dirs=(
        "/etc/arpwatch"
        "/etc/suricata/rules/mitm-detection.rules"
        "/etc/fail2ban/jail.d/mitm-protection.conf"
        "/etc/fail2ban/filter.d/arp-spoofing.conf"
        "/etc/fail2ban/filter.d/dns-spoofing.conf"
        "/etc/fail2ban/filter.d/ssl-mitm.conf"
        "/opt/mitm-protection"
        "/usr/local/bin/mitm-status"
        "/usr/local/bin/ssl-monitor.py"
        "/usr/local/bin/security-alert.py"
        "/etc/systemd/system/mitm-monitor.service"
        "/etc/systemd/system/arpwatch.service"
    )
    
    for item in "${config_dirs[@]}"; do
        if [[ -e "$item" ]]; then
            print_info "Entferne: $item"
            sudo rm -rf "$item"
            print_success "Entfernt: $item"
        fi
    done
    
    # Systemd neu laden
    sudo systemctl daemon-reload
    print_success "Systemd-Konfiguration neu geladen"
}

# Cron-Jobs entfernen
remove_cron_jobs() {
    print_header "CRON-JOBS ENTFERNEN"
    
    print_info "Entferne MITM-bezogene Cron-Jobs..."
    
    # Root-Crontab bereinigen
    sudo crontab -l 2>/dev/null | grep -v "mitm\|ssl-monitor\|security-alert" | sudo crontab - 2>/dev/null || true
    
    # Benutzer-Crontab bereinigen
    crontab -l 2>/dev/null | grep -v "mitm\|ssl-monitor\|security-alert" | crontab - 2>/dev/null || true
    
    print_success "Cron-Jobs entfernt"
}

# Log-Dateien bereinigen
cleanup_logs() {
    print_header "LOG-DATEIEN BEREINIGEN"
    
    local log_files=(
        "/var/log/arpwatch.log"
        "/var/log/suricata/"
        "/var/log/mitm-monitor.log"
        "/var/log/unbound.log"
    )
    
    for log_item in "${log_files[@]}"; do
        if [[ -e "$log_item" ]]; then
            print_info "Entferne Logs: $log_item"
            sudo rm -rf "$log_item"
            print_success "Logs entfernt: $log_item"
        fi
    done
}

# Pakete deinstallieren (optional)
remove_packages() {
    print_header "PAKETE DEINSTALLIEREN"
    
    read -p "Möchten Sie die installierten Sicherheitspakete entfernen? (j/N): " remove_pkgs
    
    if [[ "$remove_pkgs" =~ ^[jJyY]$ ]]; then
        local packages=(
            "arpwatch"
            "suricata"
            "fail2ban"
            "unbound"
        )
        
        for package in "${packages[@]}"; do
            if pacman -Qi "$package" &>/dev/null; then
                print_info "Entferne Paket: $package"
                sudo pacman -Rs --noconfirm "$package" || {
                    print_warning "Konnte $package nicht entfernen"
                }
            fi
        done
        
        print_success "Pakete entfernt"
    else
        print_info "Pakete bleiben installiert"
    fi
}

# Installationsverzeichnis entfernen
remove_installation_directory() {
    print_header "INSTALLATIONSVERZEICHNIS ENTFERNEN"
    
    local install_dirs=(
        "$HOME/mitm-protection"
        "$HOME/manjaro-mitm-protection"
    )
    
    for dir in "${install_dirs[@]}"; do
        if [[ -d "$dir" ]]; then
            print_info "Entferne Installationsverzeichnis: $dir"
            rm -rf "$dir"
            print_success "Verzeichnis entfernt: $dir"
        fi
    done
}

# Kernel-Parameter zurücksetzen
reset_kernel_parameters() {
    print_header "KERNEL-PARAMETER ZURÜCKSETZEN"
    
    print_info "Setze Netzwerk-Sicherheitsparameter zurück..."
    
    # Sysctl-Konfiguration entfernen
    if [[ -f /etc/sysctl.d/99-mitm-protection.conf ]]; then
        sudo rm /etc/sysctl.d/99-mitm-protection.conf
        print_success "Sysctl-Konfiguration entfernt"
    fi
    
    # Parameter auf Standard zurücksetzen
    local params=(
        "net.ipv4.ip_forward=0"
        "net.ipv4.conf.all.send_redirects=1"
        "net.ipv4.conf.all.accept_redirects=1"
        "net.ipv4.conf.all.secure_redirects=1"
        "net.ipv4.conf.all.accept_source_route=0"
        "net.ipv4.conf.all.log_martians=0"
    )
    
    for param in "${params[@]}"; do
        sudo sysctl -w "$param" >/dev/null 2>&1 || true
    done
    
    print_success "Kernel-Parameter zurückgesetzt"
}

# Abschließende Überprüfung
verify_removal() {
    print_header "DEINSTALLATION ÜBERPRÜFEN"
    
    local remaining_issues=()
    
    # Services prüfen
    local services=("arpwatch" "suricata" "fail2ban" "mitm-monitor")
    for service in "${services[@]}"; do
        if systemctl is-active --quiet "$service" 2>/dev/null; then
            remaining_issues+=("Service $service läuft noch")
        fi
    done
    
    # Konfigurationsdateien prüfen
    if [[ -d "/opt/mitm-protection" ]]; then
        remaining_issues+=("Konfigurationsverzeichnis /opt/mitm-protection existiert noch")
    fi
    
    # SSH-Port prüfen
    if ss -tlnp | grep -q ":2222 "; then
        remaining_issues+=("SSH läuft noch auf Port 2222")
    fi
    
    if [[ ${#remaining_issues[@]} -eq 0 ]]; then
        print_success "Deinstallation vollständig abgeschlossen"
    else
        print_warning "Folgende Probleme wurden gefunden:"
        for issue in "${remaining_issues[@]}"; do
            echo "  - $issue"
        done
    fi
}

# Hauptfunktion
main() {
    clear
    print_header "MANJARO LINUX MITM PROTECTION DEINSTALLER"
    
    cat << EOF
${YELLOW}WARNUNG: Dieses Skript wird alle MITM-Schutzkomponenten entfernen!${NC}

Folgende Aktionen werden durchgeführt:
• Services stoppen und deaktivieren
• Firewall-Regeln zurücksetzen
• SSH-Konfiguration wiederherstellen
• Konfigurationsdateien entfernen
• Log-Dateien bereinigen
• Cron-Jobs entfernen

EOF
    
    read -p "Möchten Sie wirklich deinstallieren? (j/N): " confirm
    if [[ ! "$confirm" =~ ^[jJyY]$ ]]; then
        print_info "Deinstallation abgebrochen."
        exit 0
    fi
    
    log "INFO" "MITM Protection Deinstallation gestartet"
    
    stop_services
    reset_firewall
    restore_ssh_config
    remove_config_files
    remove_cron_jobs
    cleanup_logs
    reset_kernel_parameters
    remove_packages
    remove_installation_directory
    verify_removal
    
    print_header "DEINSTALLATION ABGESCHLOSSEN"
    
    cat << EOF
${GREEN}✓ MITM-Schutz erfolgreich deinstalliert!${NC}

${BLUE}Durchgeführte Aktionen:${NC}
• Alle Services gestoppt und deaktiviert
• Firewall-Regeln zurückgesetzt
• SSH-Konfiguration wiederhergestellt
• Konfigurationsdateien entfernt
• Log-Dateien bereinigt

${YELLOW}WICHTIGE HINWEISE:${NC}
• SSH läuft wieder auf Port 22
• Firewall ist deaktiviert
• System ist nicht mehr vor MITM-Angriffen geschützt

${BLUE}Log-Datei:${NC} $LOG_FILE

EOF
    
    log "INFO" "MITM Protection Deinstallation erfolgreich abgeschlossen"
}

# Skript ausführen
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi

