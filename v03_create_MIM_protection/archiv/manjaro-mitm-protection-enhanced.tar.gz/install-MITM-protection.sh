#!/bin/bash

# =============================================================================
# MANJARO LINUX MITM PROTECTION INSTALLER
# =============================================================================
# Automatisches Installationsskript für umfassenden MITM-Schutz
# Autor: Manus AI
# Version: 1.0
# Datum: 20. Juli 2025
# =============================================================================

set -euo pipefail  # Strict error handling

# =============================================================================
# KONFIGURATION UND VARIABLEN
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/tmp/mitm-protection-install.log"
BACKUP_DIR="/tmp/mitm-protection-backup-$(date +%Y%m%d-%H%M%S)"
INSTALL_DIR="$HOME/mitm-protection"

# Farben für Ausgabe
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Standard-Konfiguration
DEFAULT_EMAIL="admin@$(hostname -f)"
DEFAULT_SSH_PORT="2222"
DEFAULT_INTERFACE=""

# =============================================================================
# HILFSFUNKTIONEN
# =============================================================================

# Logging-Funktion
log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" | tee -a "$LOG_FILE"
}

# Farbige Ausgabe
print_header() {
    echo -e "\n${PURPLE}==============================================================================${NC}"
    echo -e "${PURPLE}$1${NC}"
    echo -e "${PURPLE}==============================================================================${NC}\n"
}

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
    log "INFO" "$1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
    log "SUCCESS" "$1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
    log "WARNING" "$1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
    log "ERROR" "$1"
}

# Benutzer-Eingabe mit Validierung
get_user_input() {
    local prompt="$1"
    local default="$2"
    local validation_func="${3:-}"
    local input
    
    while true; do
        if [[ -n "$default" ]]; then
            read -p "$prompt [$default]: " input
            input="${input:-$default}"
        else
            read -p "$prompt: " input
        fi
        
        if [[ -z "$validation_func" ]] || $validation_func "$input"; then
            echo "$input"
            return 0
        else
            print_error "Ungültige Eingabe. Bitte versuchen Sie es erneut."
        fi
    done
}

# E-Mail-Validierung
validate_email() {
    local email="$1"
    if [[ "$email" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
        return 0
    else
        print_error "Ungültige E-Mail-Adresse."
        return 1
    fi
}

# Port-Validierung
validate_port() {
    local port="$1"
    if [[ "$port" =~ ^[0-9]+$ ]] && [ "$port" -ge 1024 ] && [ "$port" -le 65535 ]; then
        return 0
    else
        print_error "Port muss eine Zahl zwischen 1024 und 65535 sein."
        return 1
    fi
}

# Netzwerkschnittstellen-Validierung
validate_interface() {
    local interface="$1"
    if ip link show "$interface" &>/dev/null; then
        return 0
    else
        print_error "Netzwerkschnittstelle '$interface' nicht gefunden."
        return 1
    fi
}

# Systemvoraussetzungen prüfen
check_system_requirements() {
    print_header "SYSTEMVORAUSSETZUNGEN PRÜFEN"
    
    # Manjaro/Arch Linux prüfen
    if ! command -v pacman &> /dev/null; then
        print_error "Dieses Skript ist nur für Manjaro/Arch Linux geeignet."
        exit 1
    fi
    
    print_success "Manjaro/Arch Linux erkannt"
    
    # Root-Rechte prüfen
    if [[ $EUID -eq 0 ]]; then
        print_error "Dieses Skript sollte NICHT als root ausgeführt werden."
        print_info "Führen Sie es als normaler Benutzer aus. Sudo wird bei Bedarf verwendet."
        exit 1
    fi
    
    # Sudo-Berechtigung prüfen
    if ! sudo -n true 2>/dev/null; then
        print_info "Sudo-Berechtigung erforderlich. Bitte geben Sie Ihr Passwort ein:"
        sudo -v || {
            print_error "Sudo-Berechtigung erforderlich für die Installation."
            exit 1
        }
    fi
    
    print_success "Sudo-Berechtigung bestätigt"
    
    # Internetverbindung prüfen
    if ! ping -c 1 8.8.8.8 &> /dev/null; then
        print_error "Keine Internetverbindung verfügbar."
        exit 1
    fi
    
    print_success "Internetverbindung verfügbar"
    
    # Speicherplatz prüfen (mindestens 5GB)
    local available_space=$(df / | awk 'NR==2 {print $4}')
    local required_space=5242880  # 5GB in KB
    
    if [[ $available_space -lt $required_space ]]; then
        print_error "Nicht genügend Speicherplatz. Mindestens 5GB erforderlich."
        exit 1
    fi
    
    print_success "Ausreichend Speicherplatz verfügbar"
    
    # RAM prüfen (mindestens 2GB)
    local total_ram=$(free -m | awk 'NR==2{print $2}')
    if [[ $total_ram -lt 2048 ]]; then
        print_warning "Weniger als 2GB RAM verfügbar. Performance könnte beeinträchtigt sein."
    else
        print_success "Ausreichend RAM verfügbar"
    fi
}

# Netzwerkschnittstelle automatisch erkennen
detect_network_interface() {
    print_info "Erkenne Hauptnetzwerkschnittstelle..."
    
    # Aktive Schnittstelle mit Default-Route finden
    local interface=$(ip route | grep '^default' | head -1 | awk '{print $5}')
    
    if [[ -n "$interface" ]]; then
        print_success "Hauptnetzwerkschnittstelle erkannt: $interface"
        DEFAULT_INTERFACE="$interface"
    else
        print_warning "Konnte Hauptnetzwerkschnittstelle nicht automatisch erkennen."
        print_info "Verfügbare Netzwerkschnittstellen:"
        ip link show | grep -E '^[0-9]+:' | awk -F': ' '{print "  - " $2}' | sed 's/@.*//'
    fi
}

# Benutzer-Konfiguration sammeln
collect_user_configuration() {
    print_header "KONFIGURATION"
    
    print_info "Bitte geben Sie die folgenden Informationen ein:"
    echo
    
    # E-Mail-Adresse
    ADMIN_EMAIL=$(get_user_input "E-Mail-Adresse für Benachrichtigungen" "$DEFAULT_EMAIL" "validate_email")
    
    # SSH-Port
    SSH_PORT=$(get_user_input "SSH-Port (wird von 22 geändert)" "$DEFAULT_SSH_PORT" "validate_port")
    
    # Netzwerkschnittstelle
    if [[ -n "$DEFAULT_INTERFACE" ]]; then
        NETWORK_INTERFACE=$(get_user_input "Hauptnetzwerkschnittstelle" "$DEFAULT_INTERFACE" "validate_interface")
    else
        NETWORK_INTERFACE=$(get_user_input "Hauptnetzwerkschnittstelle (z.B. eth0, enp0s3)" "" "validate_interface")
    fi
    
    # Bestätigung anzeigen
    echo
    print_info "Konfiguration:"
    echo "  E-Mail:              $ADMIN_EMAIL"
    echo "  SSH-Port:            $SSH_PORT"
    echo "  Netzwerkschnittstelle: $NETWORK_INTERFACE"
    echo
    
    read -p "Ist diese Konfiguration korrekt? (j/N): " confirm
    if [[ ! "$confirm" =~ ^[jJyY]$ ]]; then
        print_info "Installation abgebrochen."
        exit 0
    fi
}

# System-Backup erstellen
create_system_backup() {
    print_header "SYSTEM-BACKUP ERSTELLEN"
    
    print_info "Erstelle Backup wichtiger Konfigurationsdateien..."
    mkdir -p "$BACKUP_DIR"
    
    # SSH-Konfiguration
    if [[ -f /etc/ssh/sshd_config ]]; then
        sudo cp /etc/ssh/sshd_config "$BACKUP_DIR/sshd_config.backup"
        print_success "SSH-Konfiguration gesichert"
    fi
    
    # Firewall-Status
    sudo ufw status > "$BACKUP_DIR/ufw_status.backup" 2>/dev/null || true
    
    # Aktuelle iptables-Regeln
    sudo iptables-save > "$BACKUP_DIR/iptables.backup" 2>/dev/null || true
    
    # Systemd-Services
    systemctl list-unit-files --state=enabled > "$BACKUP_DIR/enabled_services.backup"
    
    print_success "Backup erstellt in: $BACKUP_DIR"
}

# Pakete installieren
install_packages() {
    print_header "PAKETE INSTALLIEREN"
    
    print_info "Aktualisiere Paketdatenbank..."
    sudo pacman -Sy --noconfirm
    
    print_info "Installiere Basis-Pakete..."
    local base_packages=(
        "ansible"
        "python"
        "python-pip"
        "python-yaml"
        "python-jinja"
        "git"
        "curl"
        "wget"
        "base-devel"
    )
    
    for package in "${base_packages[@]}"; do
        if ! pacman -Qi "$package" &>/dev/null; then
            print_info "Installiere $package..."
            sudo pacman -S --noconfirm "$package" || {
                print_error "Fehler beim Installieren von $package"
                exit 1
            }
        else
            print_info "$package ist bereits installiert"
        fi
    done
    
    print_info "Installiere MITM-Schutz-Pakete..."
    local security_packages=(
        "arpwatch"
        "suricata"
        "fail2ban"
        "ufw"
        "unbound"
        "tcpdump"
        "wireshark-cli"
        "nmap"
        "openssl"
        "bind-tools"
    )
    
    for package in "${security_packages[@]}"; do
        if ! pacman -Qi "$package" &>/dev/null; then
            print_info "Installiere $package..."
            sudo pacman -S --noconfirm "$package" || {
                print_warning "Konnte $package nicht installieren - wird übersprungen"
            }
        else
            print_info "$package ist bereits installiert"
        fi
    done
    
    print_success "Alle Pakete installiert"
}

# Python-Abhängigkeiten installieren
install_python_dependencies() {
    print_header "PYTHON-ABHÄNGIGKEITEN INSTALLIEREN"
    
    print_info "Installiere Python-Pakete..."
    local python_packages=(
        "jinja2"
        "pyyaml"
        "netaddr"
        "dnspython"
    )
    
    for package in "${python_packages[@]}"; do
        print_info "Installiere Python-Paket: $package"
        pip3 install --user "$package" || {
            print_warning "Konnte Python-Paket $package nicht installieren"
        }
    done
    
    print_success "Python-Abhängigkeiten installiert"
}

# Ansible-Konfiguration erstellen
setup_ansible_configuration() {
    print_header "ANSIBLE-KONFIGURATION ERSTELLEN"
    
    # Arbeitsverzeichnis erstellen
    mkdir -p "$INSTALL_DIR"
    cd "$INSTALL_DIR"
    
    # Inventory-Datei erstellen
    print_info "Erstelle Ansible-Inventory..."
    cat > inventory.ini << EOF
# Ansible Inventory für Manjaro MITM Protection
[manjaro_hosts]
localhost ansible_connection=local

[manjaro_hosts:vars]
ansible_become=yes
ansible_become_method=sudo
ansible_python_interpreter=/usr/bin/python3

# MITM Protection Konfiguration
admin_email=$ADMIN_EMAIL
primary_interface=$NETWORK_INTERFACE
ssh_port=$SSH_PORT
alert_threshold_arp=3
alert_threshold_dns=5
log_retention_days=30
EOF
    
    print_success "Inventory-Datei erstellt: $INSTALL_DIR/inventory.ini"
    
    # Ansible-Konfigurationsdatei
    print_info "Erstelle Ansible-Konfiguration..."
    cat > ansible.cfg << EOF
[defaults]
inventory = inventory.ini
host_key_checking = False
timeout = 30
gathering = smart
fact_caching = memory
stdout_callback = yaml
bin_ansible_callbacks = True

[ssh_connection]
ssh_args = -o ControlMaster=auto -o ControlPersist=60s -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no
pipelining = True
EOF
    
    print_success "Ansible-Konfiguration erstellt"
}

# Playbook-Dateien kopieren
copy_playbook_files() {
    print_header "PLAYBOOK-DATEIEN KOPIEREN"
    
    if [[ -f "$SCRIPT_DIR/manjaro_mitm_protection.yml" ]]; then
        print_info "Kopiere Playbook-Dateien..."
        cp "$SCRIPT_DIR/manjaro_mitm_protection.yml" "$INSTALL_DIR/"
        
        if [[ -d "$SCRIPT_DIR/templates" ]]; then
            cp -r "$SCRIPT_DIR/templates" "$INSTALL_DIR/"
            print_success "Template-Dateien kopiert"
        fi
        
        if [[ -f "$SCRIPT_DIR/README.md" ]]; then
            cp "$SCRIPT_DIR/README.md" "$INSTALL_DIR/"
        fi
        
        if [[ -f "$SCRIPT_DIR/INSTALL.md" ]]; then
            cp "$SCRIPT_DIR/INSTALL.md" "$INSTALL_DIR/"
        fi
        
        print_success "Playbook-Dateien kopiert nach: $INSTALL_DIR"
    else
        print_error "Playbook-Dateien nicht gefunden in: $SCRIPT_DIR"
        print_info "Stelle sicher, dass alle Dateien im gleichen Verzeichnis sind."
        exit 1
    fi
}

# Ansible-Playbook ausführen
run_ansible_playbook() {
    print_header "MITM-SCHUTZ INSTALLIEREN"
    
    cd "$INSTALL_DIR"
    
    print_info "Führe Ansible-Playbook aus..."
    print_warning "Dies kann einige Minuten dauern..."
    
    # Playbook-Syntax prüfen
    print_info "Prüfe Playbook-Syntax..."
    if ! ansible-playbook --syntax-check manjaro_mitm_protection.yml; then
        print_error "Syntax-Fehler im Playbook"
        exit 1
    fi
    
    print_success "Playbook-Syntax ist korrekt"
    
    # Trockenlauf
    print_info "Führe Trockenlauf durch..."
    if ! ansible-playbook --check manjaro_mitm_protection.yml; then
        print_warning "Trockenlauf zeigte Probleme - Installation wird trotzdem fortgesetzt"
    else
        print_success "Trockenlauf erfolgreich"
    fi
    
    # Tatsächliche Installation
    print_info "Starte Installation..."
    if ansible-playbook manjaro_mitm_protection.yml; then
        print_success "MITM-Schutz erfolgreich installiert!"
    else
        print_error "Fehler bei der Installation"
        print_info "Prüfe die Logs für Details: $LOG_FILE"
        exit 1
    fi
}

# System-Status überprüfen
verify_installation() {
    print_header "INSTALLATION ÜBERPRÜFEN"
    
    print_info "Überprüfe installierte Services..."
    
    local services=("arpwatch" "suricata" "fail2ban" "unbound" "sshd")
    local failed_services=()
    
    for service in "${services[@]}"; do
        if systemctl is-active --quiet "$service"; then
            print_success "$service ist aktiv"
        else
            print_warning "$service ist nicht aktiv"
            failed_services+=("$service")
        fi
    done
    
    # UFW-Status prüfen
    if sudo ufw status | grep -q "Status: active"; then
        print_success "UFW Firewall ist aktiv"
    else
        print_warning "UFW Firewall ist nicht aktiv"
    fi
    
    # SSH-Port prüfen
    if ss -tlnp | grep -q ":$SSH_PORT "; then
        print_success "SSH läuft auf Port $SSH_PORT"
    else
        print_warning "SSH läuft möglicherweise nicht auf Port $SSH_PORT"
    fi
    
    # MITM-Status-Skript ausführen
    if [[ -f "/usr/local/bin/mitm-status" ]]; then
        print_info "Führe MITM-Status-Check aus..."
        sudo /usr/local/bin/mitm-status || print_warning "Status-Check zeigte Probleme"
    fi
    
    if [[ ${#failed_services[@]} -eq 0 ]]; then
        print_success "Alle Services laufen ordnungsgemäß"
    else
        print_warning "Folgende Services benötigen Aufmerksamkeit: ${failed_services[*]}"
    fi
}

# Abschließende Informationen
show_final_information() {
    print_header "INSTALLATION ABGESCHLOSSEN"
    
    cat << EOF
${GREEN}✓ MITM-Schutz erfolgreich installiert!${NC}

${YELLOW}WICHTIGE INFORMATIONEN:${NC}

${BLUE}SSH-Zugang:${NC}
  - SSH läuft jetzt auf Port: ${YELLOW}$SSH_PORT${NC}
  - Verbindung: ${CYAN}ssh -p $SSH_PORT $(whoami)@$(hostname)${NC}
  - Passwort-Authentifizierung ist deaktiviert

${BLUE}Installierte Services:${NC}
  - Arpwatch (ARP-Monitoring)
  - Suricata (Intrusion Detection)
  - Fail2ban (Automatische Blockierung)
  - Unbound (Sicherer DNS)
  - UFW (Firewall)

${BLUE}Monitoring:${NC}
  - Status prüfen: ${CYAN}sudo /usr/local/bin/mitm-status${NC}
  - Logs anzeigen: ${CYAN}sudo journalctl -f -u arpwatch -u suricata -u fail2ban${NC}
  - Fail2ban Status: ${CYAN}sudo fail2ban-client status${NC}

${BLUE}Konfiguration:${NC}
  - Installationsverzeichnis: ${YELLOW}$INSTALL_DIR${NC}
  - Backup-Verzeichnis: ${YELLOW}$BACKUP_DIR${NC}
  - Log-Datei: ${YELLOW}$LOG_FILE${NC}

${BLUE}E-Mail-Benachrichtigungen:${NC}
  - Konfiguriert für: ${YELLOW}$ADMIN_EMAIL${NC}
  - Für funktionsfähige E-Mails konfigurieren Sie einen Mail-Server

${YELLOW}NÄCHSTE SCHRITTE:${NC}
1. Testen Sie die SSH-Verbindung auf Port $SSH_PORT
2. Überprüfen Sie die Service-Status
3. Konfigurieren Sie E-Mail-Benachrichtigungen
4. Lesen Sie die Dokumentation in $INSTALL_DIR

${RED}WARNUNG:${NC}
- SSH läuft jetzt auf Port $SSH_PORT statt 22
- Stellen Sie sicher, dass Sie sich verbinden können, bevor Sie die aktuelle Sitzung beenden
- Bei Problemen: Backup in $BACKUP_DIR verfügbar

EOF
}

# Fehlerbehandlung
cleanup_on_error() {
    print_error "Installation fehlgeschlagen!"
    print_info "Backup verfügbar in: $BACKUP_DIR"
    print_info "Log-Datei: $LOG_FILE"
    
    read -p "Möchten Sie die Änderungen rückgängig machen? (j/N): " rollback
    if [[ "$rollback" =~ ^[jJyY]$ ]]; then
        print_info "Führe Rollback durch..."
        
        # SSH-Konfiguration wiederherstellen
        if [[ -f "$BACKUP_DIR/sshd_config.backup" ]]; then
            sudo cp "$BACKUP_DIR/sshd_config.backup" /etc/ssh/sshd_config
            sudo systemctl restart sshd
            print_success "SSH-Konfiguration wiederhergestellt"
        fi
        
        # Services stoppen
        for service in arpwatch suricata fail2ban; do
            sudo systemctl stop "$service" 2>/dev/null || true
            sudo systemctl disable "$service" 2>/dev/null || true
        done
        
        print_success "Rollback abgeschlossen"
    fi
    
    exit 1
}

# =============================================================================
# HAUPTPROGRAMM
# =============================================================================

main() {
    # Fehlerbehandlung einrichten
    trap cleanup_on_error ERR
    
    # Header anzeigen
    clear
    print_header "MANJARO LINUX MITM PROTECTION INSTALLER"
    
    cat << EOF
${CYAN}Willkommen zum automatischen MITM-Schutz-Installer!${NC}

Dieses Skript wird folgende Komponenten installieren und konfigurieren:
• Arpwatch (ARP-Spoofing-Erkennung)
• Suricata (Intrusion Detection System)
• Fail2ban (Automatische Bedrohungsabwehr)
• Unbound (Sicherer DNS-Resolver)
• UFW (Firewall-Konfiguration)
• SSH-Sicherheitshärtung

${YELLOW}WARNUNG: Dieses Skript wird Systemkonfigurationen ändern!${NC}
Ein Backup wird automatisch erstellt.

EOF
    
    read -p "Möchten Sie fortfahren? (j/N): " proceed
    if [[ ! "$proceed" =~ ^[jJyY]$ ]]; then
        print_info "Installation abgebrochen."
        exit 0
    fi
    
    # Installationsschritte ausführen
    log "INFO" "MITM Protection Installation gestartet"
    
    check_system_requirements
    detect_network_interface
    collect_user_configuration
    create_system_backup
    install_packages
    install_python_dependencies
    setup_ansible_configuration
    copy_playbook_files
    run_ansible_playbook
    verify_installation
    show_final_information
    
    log "INFO" "MITM Protection Installation erfolgreich abgeschlossen"
    print_success "Installation erfolgreich abgeschlossen!"
}

# Skript ausführen
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi

