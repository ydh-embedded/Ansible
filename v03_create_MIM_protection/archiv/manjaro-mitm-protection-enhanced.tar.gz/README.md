# Manjaro Linux MITM Protection Suite

**Umfassender Schutz vor Man-in-the-Middle-Angriffen für Manjaro Linux**

Autor: Manus AI  
Version: 1.0  
Datum: 20. Juli 2025

## Übersicht

Dieses Ansible-Playbook bietet eine vollständige Lösung zum Schutz von Manjaro Linux-Systemen vor Man-in-the-Middle (MITM) Angriffen. Es implementiert mehrschichtige Sicherheitsmaßnahmen, die speziell für die Arch-basierte Manjaro-Distribution optimiert sind.

### Hauptfunktionen

- **ARP-Spoofing-Erkennung** mit Arpwatch
- **Intrusion Detection System** mit Suricata
- **Automatische Bedrohungsabwehr** mit Fail2ban
- **DNS-Sicherheit** mit Unbound und DNSSEC
- **SSH-Härtung** mit erweiterten Sicherheitseinstellungen
- **Firewall-Konfiguration** mit UFW
- **Kontinuierliches Monitoring** mit benutzerdefinierten Skripten
- **Automatische Benachrichtigungen** bei erkannten Bedrohungen

### Architektur

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Netzwerk-     │    │   Intrusion     │    │   Automatische  │
│   Monitoring    │───▶│   Detection     │───▶│   Reaktion      │
│   (Arpwatch)    │    │   (Suricata)    │    │   (Fail2ban)    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   DNS-Sicher-   │    │   SSH-Härtung   │    │   Firewall      │
│   heit (Unbound)│    │   & Monitoring  │    │   (UFW)         │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Systemanforderungen

### Unterstützte Systeme
- Manjaro Linux (alle Editionen)
- Arch Linux (mit geringfügigen Anpassungen)

### Hardware-Anforderungen
- Mindestens 2 GB RAM
- 5 GB freier Festplattenspeicher
- Netzwerkschnittstelle mit Administratorrechten

### Software-Voraussetzungen
- Python 3.8 oder höher
- Ansible 2.9 oder höher
- Sudo-Berechtigung für den Ansible-Benutzer

## Installation

### 1. Ansible Installation

Auf dem Control Node (dem System, von dem aus Sie das Playbook ausführen):

```bash
# Auf Manjaro/Arch Linux
sudo pacman -S ansible python-pip

# Auf anderen Systemen
pip3 install ansible
```

### 2. Playbook herunterladen

```bash
# Repository klonen oder Dateien herunterladen
mkdir manjaro-mitm-protection
cd manjaro-mitm-protection

# Alle Dateien in dieses Verzeichnis kopieren
```

### 3. Inventory konfigurieren

Bearbeiten Sie die Datei `inventory.ini`:

```ini
[manjaro_hosts]
# Ihre Manjaro-Hosts hier eintragen
manjaro-desktop ansible_host=192.168.1.100 ansible_user=ihr_benutzername
manjaro-laptop ansible_host=192.168.1.101 ansible_user=ihr_benutzername

[manjaro_hosts:vars]
admin_email=ihre_email@example.com
primary_interface=eth0  # Ihre Hauptnetzwerkschnittstelle
ssh_port=2222
```

### 4. SSH-Schlüssel einrichten

```bash
# SSH-Schlüssel generieren (falls noch nicht vorhanden)
ssh-keygen -t rsa -b 4096

# Öffentlichen Schlüssel auf Ziel-Hosts kopieren
ssh-copy-id ihr_benutzername@192.168.1.100
```

### 5. Playbook ausführen

```bash
# Vollständige Installation
ansible-playbook -i inventory.ini manjaro_mitm_protection.yml

# Nur bestimmte Tags ausführen
ansible-playbook -i inventory.ini manjaro_mitm_protection.yml --tags "monitoring,ids"

# Trockenlauf (ohne Änderungen)
ansible-playbook -i inventory.ini manjaro_mitm_protection.yml --check
```

## Konfiguration

### Wichtige Variablen

Die folgenden Variablen können in der `inventory.ini` oder in separaten Variablendateien angepasst werden:

```yaml
# Netzwerk-Konfiguration
primary_interface: "eth0"           # Hauptnetzwerkschnittstelle
monitoring_interfaces:              # Zu überwachende Schnittstellen
  - "eth0"
  - "wlan0"

# Sicherheits-Konfiguration
ssh_port: 2222                     # Benutzerdefinierter SSH-Port
admin_email: "admin@example.com"   # E-Mail für Benachrichtigungen

# Firewall-Regeln
allowed_tcp_ports:                 # Erlaubte TCP-Ports
  - 22
  - 2222
  - 80
  - 443

# Monitoring-Einstellungen
alert_threshold_arp: 3             # ARP-Änderungen bis Alarm
alert_threshold_dns: 5             # DNS-Anomalien bis Alarm
log_retention_days: 30             # Log-Aufbewahrung in Tagen
```

### Erweiterte Konfiguration

Für erweiterte Anpassungen können Sie die Template-Dateien im `templates/` Verzeichnis bearbeiten:

- `suricata.yaml.j2` - Suricata IDS-Konfiguration
- `unbound.conf.j2` - DNS-Sicherheitskonfiguration
- `fail2ban-mitm.conf.j2` - Fail2ban-Regeln
- `mitm-detection.rules.j2` - Benutzerdefinierte Suricata-Regeln

## Verwendung

### Status überprüfen

```bash
# Auf dem Ziel-Host
sudo /usr/local/bin/mitm-status

# JSON-Ausgabe für Automatisierung
sudo /usr/local/bin/mitm-status --json
```

### Logs überwachen

```bash
# Arpwatch-Logs
sudo tail -f /var/log/arpwatch.log

# Suricata-Alerts
sudo tail -f /var/log/suricata/eve.json | jq '.alert'

# Fail2ban-Status
sudo fail2ban-client status

# Systemweite Sicherheitslogs
sudo journalctl -f -u arpwatch -u suricata -u fail2ban
```

### Manuelle Tests

```bash
# ARP-Tabelle überprüfen
arp -a

# DNS-Auflösung testen
dig @127.0.0.1 example.com +dnssec

# Firewall-Status
sudo ufw status verbose

# SSH-Konfiguration validieren
sudo sshd -T
```

## Wartung

### Regelmäßige Aufgaben

Das Playbook richtet automatische Wartungsaufgaben ein:

- **Tägliche Statusberichte** (6:00 Uhr)
- **SSL-Zertifikat-Überwachung** (2:00 Uhr)
- **Regel-Updates** (wöchentlich)
- **Log-Rotation** (täglich)

### Manuelle Updates

```bash
# Suricata-Regeln aktualisieren
sudo suricata-update

# System-Updates
sudo pacman -Syu

# Playbook erneut ausführen (idempotent)
ansible-playbook -i inventory.ini manjaro_mitm_protection.yml
```

## Fehlerbehebung

### Häufige Probleme

#### 1. Arpwatch startet nicht

```bash
# Berechtigungen überprüfen
sudo chown root:root /var/lib/arpwatch
sudo chmod 755 /var/lib/arpwatch

# Service neu starten
sudo systemctl restart arpwatch
```

#### 2. Suricata-Regeln laden nicht

```bash
# Regel-Syntax überprüfen
sudo suricata -T -c /etc/suricata/suricata.yaml

# Regeln manuell laden
sudo systemctl reload suricata
```

#### 3. DNS-Auflösung funktioniert nicht

```bash
# Unbound-Konfiguration testen
sudo unbound-checkconf

# DNS-Weiterleitung testen
dig @127.0.0.1 google.com
```

#### 4. Fail2ban blockiert legitimen Verkehr

```bash
# IP-Adresse entsperren
sudo fail2ban-client set <jail_name> unbanip <ip_address>

# Jail-Status überprüfen
sudo fail2ban-client status <jail_name>
```

### Log-Analyse

```bash
# Fehler in Systemlogs finden
sudo journalctl --since "1 hour ago" --priority=err

# Service-spezifische Logs
sudo journalctl -u arpwatch --since today
sudo journalctl -u suricata --since today
sudo journalctl -u fail2ban --since today
```

## Sicherheitshinweise

### Wichtige Überlegungen

1. **SSH-Zugang**: Nach der Ausführung läuft SSH auf Port 2222. Stellen Sie sicher, dass Sie sich mit dem neuen Port verbinden können.

2. **Firewall-Regeln**: Das Playbook aktiviert UFW mit restriktiven Regeln. Überprüfen Sie, ob alle benötigten Dienste erreichbar sind.

3. **E-Mail-Benachrichtigungen**: Konfigurieren Sie einen lokalen Mail-Server oder SMTP-Relay für Benachrichtigungen.

4. **Performance**: Suricata kann ressourcenintensiv sein. Überwachen Sie die Systemleistung nach der Installation.

### Best Practices

- Führen Sie das Playbook zunächst in einer Testumgebung aus
- Erstellen Sie regelmäßige Backups der Konfigurationsdateien
- Überwachen Sie die Logs auf False Positives
- Aktualisieren Sie Regelsätze regelmäßig
- Testen Sie die Wiederherstellungsverfahren

## Anpassung

### Eigene Regeln hinzufügen

Bearbeiten Sie `templates/mitm-detection.rules.j2`:

```bash
# Neue Regel hinzufügen
alert tcp any any -> any 8080 (msg:"Custom MITM Detection"; sid:2000001; rev:1;)
```

### Zusätzliche Services integrieren

Erweitern Sie das Hauptplaybook:

```yaml
- name: "Install additional security tool"
  pacman:
    name: additional-tool
    state: present
  tags: ['custom']
```

### Monitoring erweitern

Bearbeiten Sie `templates/network-monitor.py.j2` um zusätzliche Überwachungsfunktionen hinzuzufügen.

## Support und Beitrag

### Probleme melden

Bei Problemen oder Verbesserungsvorschlägen:

1. Überprüfen Sie die Logs auf Fehlermeldungen
2. Führen Sie das Playbook mit `-vvv` für detaillierte Ausgaben aus
3. Dokumentieren Sie Ihre Systemkonfiguration

### Beitrag leisten

Verbesserungen sind willkommen:

- Neue Erkennungsregeln
- Zusätzliche Monitoring-Funktionen
- Unterstützung für weitere Distributionen
- Dokumentationsverbesserungen

## Lizenz

Dieses Projekt steht unter der MIT-Lizenz. Siehe LICENSE-Datei für Details.

## Haftungsausschluss

Dieses Tool bietet Schutzmaßnahmen gegen MITM-Angriffe, kann aber keine 100%ige Sicherheit garantieren. Die Sicherheit Ihrer Systeme liegt in Ihrer Verantwortung. Verwenden Sie zusätzliche Sicherheitsmaßnahmen und halten Sie Ihre Systeme aktuell.

